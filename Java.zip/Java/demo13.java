import java.util.Scanner;
class demo13
{
    public static void main(String[]args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the word:");
        String input_from_question=sc.next();
        int count=0,num=0;
        for(int i=0;i<input_from_question.length()-1;i++)
        {
            for(int j=i+1;j<input_from_question.length();j++)
            {
                if(input_from_question.charAt(i)==input_from_question.charAt(j))
                {
                    count++;
                }
            }
            if(count==1)
            num++;
            count=0;
        }
        System.out.println(num);

    }
}