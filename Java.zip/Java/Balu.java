class  Balu
{public static void main(String[]args)
	{
	int a=20;
	String b="Balu";
	System.out.print("Name:");
	System.out.println(b);
	System.out.print("Age:");
	System.out.println(a);
}

}