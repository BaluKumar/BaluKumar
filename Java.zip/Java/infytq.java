//write a program to display your name and your designation
import java.util.Scanner;
class infytq1
{
   public static void main(String [] args)
   {
	   Scanner s=new Scanner(System.in);
	   int a=s.nextInt();
	   int b=s.nextInt();
	   int c=a+b;
	   if(c%2==0)
		   System.out.println(c+"\n its even number");
	   else if(c%2==-1)
		   System.out.println("\n your number negtive");
		else
			System.out.println(c+"\n its odd number");
   }
}
//
class infytq2
{
	public static void main(String [] args)
	{
		String DoorNO="D089";
		String Street="St Louis Street";
		String City="Springfield";
		int PinCode=627290;
		System.out.println("DoorNO:"+DoorNO);
		System.out.println("Street:"+Street);
		System.out.println("City"+City);
		System.out.println("PinCode:"+PinCode);
	}
	
}
//write a program to print odd or even numbers
class infytq3
{
	public static void main (String [] x)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		for(int i=1;i<=n;i++)
		{
			if(i%2==0)
				System.out.println(i+"\t it is even");
			else
				System.out.println(i+"\t it is odd");	
		}
	}
}
//write a program to print nth fibinico series 
class infytq4
{
	public static void main (String [] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int a=-1;
		int b= 1,c=0;
		for(int i=0;i<n;i++)
		{
			c=a+b;
			a=b;
		    b=c;
		}
		System.out.println(c);		
	}
}
//write a program to print n number of fibinico series
class infytq5
{
	public static void main (String [] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int a=-1;
		int b= 1,c=0;
		for(int i=0;i<n;i++)
		{
			c=a+b;
			a=b;
		    b=c;
			System.out.println(c);	
		}
			
	}
}
//Add all postive even numbers when negtive odd number is passed the program should terminate 
class infytq6
{
	public static void main(String [] a)
	{
		Scanner s=new Scanner(System.in);
		int n,c=0;
		while(true)
		{
			n=s.nextInt();
			if(n>0)
			{
				if(n%2==0)
					c=c+n;
			}else
				if(n%2==-1)
					break;
		}
		System.out.println(c);	
	}
}
//write a program using ternary Operator
class infytq7
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		String c=(n%2==0) ? "Even" : "odd";
		System.out.println(~n);
		System.out.println(c);
	}
	
}
//write a program using All the BitWise Operator
class infytq8
{
	public static void main(String [] args)
	{
		int a=103;
		int b =2;
		System.out.print("a:  "+a);
		System.out.println(" b:  "+b);
		int c= a&b;
		System.out.println("a&b  "+c);
		c= a|b;
		System.out.println("a|b  "+c);
		c= a^b;
		System.out.println("a^b  "+c);
		c= a+b;
		System.out.println("a+b  "+~c);
		c= a<<b;
		System.out.println("a<<b  "+c);
		c= a>>b;
		System.out.println("a>>b  "+c);
		c= a>>>b;
		System.out.println("a>>>b  "+c);
		int z=4;
		//System.out.println(4<<2);
		//error accoured because of no 4 is not taken as binary but as digit
		System.out.println(z<<2);
		//only int value can be sifted we cant swift decmial values
	}
}
/*implement a program to Calculate the Simple Interest by using the formula
given below and display the Calculated Simple Interest.

logic:
	SI=(principal*rate*time)/100

Sample input
		principal=3250,rate=7,time=3
		principal=5000,rate=10,time=5
*/
class infytq9
{
	public static void main(String [] args)
	{
		/*int i=10;
		if(i)//compile time error binary can't convert to boolean
			System.out.println("Hello");
		else
			System.out.println("zbye");*/
		
		int principal=3250,rate=7,time=3;
		int SI=(principal*rate*time)/100;
		System.out.println(SI);
	}
	
}
//
class infytq10
{
	public static void main(String [] args)
	{
		int v1=10;
		float v2=v1;
		System.out.println(v1);
		System.out.println(v2);
		float v3=12.5f;
		int v4=(int)v3;
		System.out.println(v3);
		System.out.println(v4);
		int v5 =(int)v3;
		System.out.println(v5);
	}
}
//
class infytq11
{
	public static void main(String [] args)
	{
		Scanner s= new Scanner(System.in);
		int r=s.nextInt();
		float pi=3.14f;
		float a=pi*r*r;
		System.out.println(a);
	}
	
}
//
class infytq12
{
	public static void main(String [] args)
	{
		Scanner s= new Scanner(System.in);
		int f=s.nextInt();
		float c=((f-32)/9)*5;
		System.out.println(c);
	}
	
}

class infytq13
{
	public static void main(String [] args)
	{
		int n=40;
		switch(n)
		{
			case 10: System.out.println("TEN");
			    break;
			case 35+5:System.out.println("fourty");
				break;
		}
	}
}

class infytq14
{
	int rats=5;
	public static void main(String [] args)
	{
		infytq14 t1=new infytq14();
	}
}

class infytq15
{
	public static void main(String []args)
	{
		
	}
}

