class E1
{
	private String Name="Swathi";
	public String getName()
	{
		return Name;
	}
	public void setName(String a)
	{
		this.Name=a;
		this.Name=this.Name+" 2";
	}
}