/*WAJP to print first not repeated character in a given string
case 1:
input:Jspiders
output:J
case 2:
input:spiders
output:p
*/
import java.util.Scanner;
class notRepChar
{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String value");
		String s1=sc.next();int count=0;
		char []ch=s1.toCharArray();
		for(int i=0;i<ch.length-1;i++)
		{
			for(int j=i+1;j<ch.length;j++)
			{
				if(ch[i]==ch[j])
					count++;
			}
			if(count==0)
			{
				System.out.println(ch[i]);
				System.exit(0);
			}count=0;
		}
	}
}