class MI1
{
	public static void main(String []args)
	{
		//case 1
		MI m=new MI();
		//case 2
		MI m1=new MIC1();
		m1.mName();
		//m1.mName1(); --> Compile Time Error
	}
}
class MI
{
	public void mName()
	{
		System.out.println("Some Name");
	}
}
class MIC1 extends MI
{
	public void mName1()
	{
		System.out.println("Amma");
	}
}
class MIC2 extends MI
{
	public void mName2()
	{
		System.out.println("APPA");
	}
}