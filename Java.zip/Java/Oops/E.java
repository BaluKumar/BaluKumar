import java.util.Scanner;
class E
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		E1 e=new E1();
		String Myname="Balu",name=e.getName();
		System.out.println(Myname+" "+name);
		char ch=s.next().charAt(0);
		if(ch=='y'||ch=='Y')
		{
			String nextName=s.next();
			e.setName(nextName);
			System.out.println(Myname+" "+nextName);
		}
		
	}
}