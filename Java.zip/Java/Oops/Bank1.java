import java.util.Scanner;
class Bank1
{
	private String Name;
	private long Contact_no;
	private String Addres;
	private long Aadhar;
	private String Pan_No;
	Scanner sc=new Scanner(System.in);
	public void setData(String Name,long Contact_no,String Addres)
	{
		this.Name=Name;
		this.Contact_no=Contact_no;
		this.Addres=Addres;
		System.out.println("Please Enter your Aadhar_no");
		this.Aadhar=sc.nextLong();
		System.out.println("Please Enter your Pan_No");
		this.Pan_No=sc.next();
	}
	public long getPassbook()
	{
		long AC_NO=54682973164l;
		return AC_NO;
	}
	public void setChanges()
	{
		System.out.println("If you want to change any of your details press y else n");
		char ch=sc.next().charAt(0);
		if(ch=='y'||ch=='Y')
		{
			System.out.println("1.Name 2.Contact_no 3.Addres 4.Aadhar 5.Pan_No;");
			int a=sc.nextInt();
			switch(a)
			{
				case 1:this.Name=sc.next();
				break;
				case 2:this.Contact_no=sc.nextLong();
				break;
				case 3:this.Addres=sc.next();
				break;
				case 4:this.Aadhar=sc.nextLong();
				break;
				case 5:this.Pan_No=sc.next();
				break;
				default:System.out.println("how can i help you");
			}
		}else
		{
			System.out.println("Thank you ");
		}
	}
	
}