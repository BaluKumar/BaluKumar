import java.util.Scanner;
/* to find prefectnumber in the given range
ex: input:3  output:3is a prefectnumber
factors of 3 are 1 , 2 
1+2=3  input:3
	|		 |
	----==----//check the condition
	
*/
class prefectnum
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int e=s.nextInt();
		int sum=0;
		for(int n=0;n<=e;n++)
		{
			for(int i=1;i<=n/2;i++)
			{
				if(n%i==0)
				{
					sum=sum+i;
				}
			}
			if(sum==n)
			{
				System.out.println(n+" is a prefectnumber");
			}
			sum=0;
		}
	}
}
