import  java.util.Scanner;
class AQI2
{
	Scanner sc=new Scanner(System.in);
	private String name;
	private int pswd;
	private long phone;
	public void setRegistration()
	{
		System.out.println("Enter your name");
		this.name=sc.next();
		System.out.println("Enter your password");
		this.pswd=sc.nextInt();
		System.out.println("Enter your phone number");
		this.phone=sc.nextLong();
		if(phone==0)
		{
			System.out.println("Enter the valid phone number");
			this.phone=sc.nextLong();
		}
		else
		{
			if(pswd!=0)
			System.out.println("you successfuly register in faceebook");
		else{
			System.out.println("enter the Valid Password ?");	
			this.pswd=sc.nextInt();
		}
		}
	}
	public String getname()
	{
		return name;
	}
	public void setpswd()
	{
		System.out.println("Enter your old password :");
		int pswd=sc.nextInt();
		if(this.pswd==pswd)
		{
			System.out.println("Enter your new password :");
			int a=sc.nextInt();
			System.out.println("Enter confirm Password :");
			int b=sc.nextInt();
			if(a==b)
			{
				this.pswd=a;
			}
		}else{
			
		}
	}
	public String getAccount(String n,int p)
	{
		if(name.equals(n)&&pswd==p)
		{
			System.out.println("Name : "+n);
			System.out.println("Phone number : "+phone);
			System.out.print("Welocome ");
		return name;
		}else{
			
			return "";
		}
	}
}