import java.util.Scanner;
class AQI
{
	private String Name;
	private int pswd;
	private long phone=7010180289l;
	private String Address="Nagondapalli village";
	Scanner sc=new Scanner(System.in);
	AQI(String a,int pswd)
	{
		this.Name=a;
		this.pswd=pswd;
	}
	public String getName()
	{
		return Name;
	}
	public void setpswd()
	{
		System.out.println("Enter your name :");
		String a=sc.next();
		if(Name.equals(a))
		{
			System.out.println("Enter the old password :");
			int pswd=sc.nextInt();
			if(this.pswd==pswd)
			{
				System.out.println("Enter the new password :");
				this.pswd=sc.nextInt();
			}
			else
			{
				System.out.println("You entred the wrong password");
			}
		}else 
		{
			System.out.println("User name is incorrect ");
		}
	}
	public void setName(String Name)
	{
		this.Name=Name;
	}
	public void getAccount(String a,int pswd)
	{
		if(Name.equals(a)&&this.pswd==pswd)
		{
			System.out.println("Name :"+Name);
			System.out.println("Phone_No :"+phone);
			System.out.println("Address :"+Address);
		}
		else
		{
			System.out.println("your name or password is incorrect ");
		}
	}
}