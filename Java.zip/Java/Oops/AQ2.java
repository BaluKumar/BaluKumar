import java.util.Scanner;
class AQ2
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		AQI2 a=new AQI2();
		a.setRegistration();
		System.out.println(a.getname());
		System.out.println("Enter your name");
		String name=s.next();
		System.out.println("enter you password");
		int pswd=s.nextInt();
		System.out.print(a.getAccount(name,pswd)+"!");
	}
}