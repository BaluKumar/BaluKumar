//import java.lang.String;
class A
{
	public static void main(String []args)
	{
		String s1="10 20 30";
		char[]ch=s1.toCharArray();
		System.out.println(ch);
	}
}