import java.util.Scanner;
class Bank
{
	public static void main(String [] args)
	{
		Scanner s=new  Scanner(System.in);
		Bank1 a=new Bank1();
		System.out.println("Enter Your Name");
		String Name=s.next();
		System.out.println("Enter your Contact_no");
		long Contact_no=s.nextLong();
		System.out.println("Enter your Addres");
		String Addres=s.next();
		a.setData(Name,Contact_no,Addres);
		Long Bankbook=a.getPassbook();
		System.out.println("your Account_no is : "+Bankbook);
		a.setChanges();
		
	}
}