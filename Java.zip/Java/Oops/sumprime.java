import java.util.Scanner;
class sumprime
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int m,n;
		m=s.nextInt();
		n=s.nextInt();
		int count=0;
		int sum=0;
		for(int i=m;i<=n;i++)
		{
			for(int j=2;j<=i/2;j++)
			{
				if(i%j==0)
					count++;
			}
			if(count==0)
			{
				System.out.println(i+" is a prime number ");
				sum=sum+i;
			}
			count=0;
		}
		System.out.println("Sum of prime Number is :"+sum);
	}
}