/*write a java programm to read a String and Print reverse of that
I/P :BALU
O/P :ULAB
*/
import java.util.Scanner;
class reverse
{
	public static void main(String[]args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter a word");
		String str=s.next();
		String str1="";
		for(int i=str.length()-1;i>=0;i--)
		{
			str1=str1+str.charAt(i);
		}
		System.out.println(str1);
	}
}