import java.util.Scanner;
/*to check the given number is phloem or not
input:13248 output: 13248is a phloem
explication:
------------------
| + |            |
1 3 2 4 8	  9==9//check the condition 
  |+|+|       |
  -------------
*/
class phloem
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		if(m1(n))
			System.out.println(n+"is a phloem");
		else
			System.out.println(n+"isn't a phloem");
	}
	public static boolean m1(int n)
	{
		int fl=0,rem=0,count=0;
		int len=(String.valueOf(n)).length();
		while(n>0)
		{
			int l=n%10;
            n/=10;
			count++;
			if(count==1||count==len)
				fl+=l;
			else
				rem+=l;
		}
		if(fl==rem)
			return true;
		else
			return false;
	}
}