import java.util.Scanner;
class revArrayString
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		String []sc=new String[n];
		for(int i=0;i<n;i++) 
		{
			sc[i]=s.next();
		}
		sc=reverse(sc,n);
		for(int i=0;i<n;i++)
		{
			System.out.print(sc[i]+" ");
		}
	}
	public static String[] reverse(String a[],int n)
	{
		String s[]=new String[n];
		for(int i=0;i<n;i++)
		{
			s[i]=a[n-(i+1)];
		}
		return s;
	}
}