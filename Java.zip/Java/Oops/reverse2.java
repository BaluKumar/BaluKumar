/*WAJP to reads words and print reverseof that 
input:welcome to java class
output:emoclew ot avaj ssalc
*/
import java.util.Scanner;
class reverse2
{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		String s1=sc.nextLine();
		String []s2=s1.split(" ");
		for(int i=0;i<s2.length;i++)
		{
			for(int j=s2[i].length()-1;j>=0;j--)
			{
				System.out.print(s2[i].charAt(j));
			}System.out.print(" ");
		}
	}
}