import java.util.Scanner;
/*write a java program to print all the prefect number in an array
case 1: a[]={6,5,3,9}
a[0]=6
factors of 6 are 1,2,3-->6
adding these three gives same as the a[0] -->6==6
*/
class prefectnum1
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the size of Array");
		int n=s.nextInt();
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=s.nextInt();
		}
		for(int i=0;i<n;i++)
		{
			int value=prefectnumber(a[i]);
			if (a[i]==value)
				System.out.println(a[i]+"is a prefectnumber");
			else
				System.out.println(a[i]+"isn't a prefectnumber");
		}
	}
	public static int prefectnumber(int n)
	{
		int sum=0;
		for(int i=1;i<n;i++)
		{
			if (n%i==0)
				sum+=i;
		}
			return sum;
	}
}