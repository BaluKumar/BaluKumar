/*WAJP to count Character in the given String 
input:hello
output:
h->1 times
e->1 times
l->2 times
o->1 times
*/
import java.util.Scanner;
class charCount
{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a string value:");
		String s1=sc.next();
	    int count=1;
		char c='0';
		char ch[]=s1.toCharArray();
		for(int i=0;i<ch.length;i++)
		{
			for(int j=i+1;j<ch.length;j++)
			{
				if(ch[i]==ch[j])
				{
					count++;
					ch[j]=c++;
				}
			}
		  if(!(ch[i]>='0' && ch[i]<='9'))
			System.out.println(s1.charAt(i)+"-->"+count);
			count=1;
		}
	}
}