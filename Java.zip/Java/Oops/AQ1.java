import java.util.Scanner;
class AQ1
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		AQI a=new AQI("Balu",2408);
		System.out.println("Enter your Name :");
		String Name=s.next();
		System.out.println("Enter your Password :");
		int pswd=s.nextInt();
		System.out.println("Welcome "+a.getName()+" !.....");
		a.getAccount(Name,pswd);
		a.setpswd();
	}
}