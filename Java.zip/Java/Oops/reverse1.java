import java.util.Scanner;
class reverse1
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		String s1=s.nextLine();
		int start=0,len=s1.length();
		System.out.println(len);
		for(int i=0;i<len;i++)
		{
			if(s1.charAt(i)==' ')
			{
				for(int j=i-1;j>=start;j--)
				{
					System.out.print(s1.charAt(j));
				}System.out.print(" ");
				start=i+1;
			}
			
			if((len-1)==i)
			{
				for(int j=len-1;j>=start;j--)
				{
					System.out.print(s1.charAt(j));
				}
			}
		}
	}
}