import java.util.Scanner;
//Solution 
import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
class scanner
{
    public static void main(String[] args) 
	{
        Scanner scan = new Scanner(System.in);
        int i = scan.nextInt();
        double d = scan.nextDouble();
        scan.nextLine();/*dout
		before geting a string value from the user 
		if you get any other value from the user then 
		you should be use "scan.nextLine()" to get the 
		string value it should be writen before string 
		scanner statment eg:"String s=scan.nextLine()"
		----------------
		if you what to get string value after a value 
		getting from the user you should not click enter
		you should sepreate by using space like that 
		you don't what to use this "scan.nextLine()"
		line in it.
		*/
        String s =scan.nextLine();
        // Write your code here.

        System.out.println("String: " + s);
        System.out.println("Double: " + d);
        System.out.println("Int: " + i);
    }
}
class printstatement
{
    public static void main(String[] args) 
	{
        Scanner sc=new Scanner(System.in);
        System.out.println("================================");
        for(int i=0;i<3;i++)
		{
            String s1=sc.next();
            int x=sc.nextInt();
            //Complete this line
            System.out.printf("%-15s%03d%n", s1, x);/*dout*/
        }
        System.out.println("================================");
    }
}

class multplicationtable 
{
    public static void main(String[] args) throws IOException 
	{
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
		/*
		it's like scanner bufferedReader
		*/
        int N = Integer.parseInt(bufferedReader.readLine().trim());/*dout*/
        for(int i=1;i<=20;i++)
        {
            System.out.println(N+" x "+i+" = "+N*i);
        }
        bufferedReader.close();
    }
}