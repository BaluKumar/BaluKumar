import java.util.Scanner;
class add 
{
	public static void main(String[]args)
	{
		Scanner s=new Scanner(System.in);
		int a,b,c,d;
		a=s.nextInt();
		b=s.nextInt();
		c=s.nextInt();
		d=s.nextInt();
		System.out.println((a+c)*(d-b));
	}
}