/*Java program to check whether the given number is even or odd
Observe the output for different values of number variable*/
import java.util.Scanner;
class DecisionControl1 
{
	public static void main(String[] args) 
	{
		Scanner s= new Scanner(System.in);
		int n=s.nextInt();
		if(n%2==0)
		{
			System.out.println(n+" is even");
		}
		else
		{
			System.out.println(n+" is odd");
		}
	}
}
//Observe the output for different values of marks  
class DecisionControl2
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		int marks = s.nextInt();

		if (marks < 40) {
			System.out.println("Fail");
		} else if (marks >= 40 && marks < 60) {
			System.out.println("D grade");
		} else if (marks >= 60 && marks < 80) {
			System.out.println("C grade");
		} else if (marks >= 80 && marks < 90) {
			System.out.println("B grade");
		} else if (marks >= 90 && marks < 95) {
			System.out.println("A grade");
		} else if (marks >= 95 && marks <= 100) {
			System.out.println("A+ grade");
		} else {
			System.out.println("Invalid!");
		}
	}
}

class DecisionControl3
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		String CT="Regular";
		int Q=s.nextInt();
		int Price=30;
		int Total=0;
		int Dis=5;
		int DeliveryCharge= 40;
		if(CT=="Regular")
		{
			System.out.println("Your are"+CT+"Customer and have "+Dis);
			Total=Price*Q;
			System.out.println("your total cost is $"+Total);
			Total = Total-(Total*Dis/100);
			System.out.println("with adding your discount. now you have to pay $"+Total);
			if(Total>=60)
				System.out.println("you got the gift voucher!!!!");
		}
		else if(CT=="Guest")
		{
			Total=Price*Q;
			System.out.println("You need to pay DeliveryCharge of $"+DeliveryCharge);
			Total=Total+DeliveryCharge;
			System.out.println("The total cost to be paid is $"+Total);
		}
		else
			System.out.println("Invalid Selection");
	}
}
//Write a program using switch case 
class DecisionControl4
{
	public static void main(String [] args)
	{
		int discount;
		String CustomerType="Premium";
		switch(CustomerType)
		{
			case "Premium":
				discount=50;
				break;
			case "Regular":
				discount=30;
				break;
			default :
				discount=10;
				System.out.println("wELCOME! Sir");
		}
		System.out.println("you got discount of "+discount+"%");
		System.out.println("\t\t Thankyou for Coming."+"Plase,Come Again!");
	}
}
//write a program to print large value among these three numbers
class DecisionControl15
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int num1=s.nextInt(),num2=s.nextInt(),num3=s.nextInt();
		if(num1>=num2)
		{
			if(num1>=num3)
				System.out.println(num1);
		}
		else if(num2>num1)
		{
			if(num2>=num3)
				System.out.println(num2);
			else
				System.out.println(num3);
		}
	}
}		