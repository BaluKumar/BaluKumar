class  ICIC_Banck
{public static void main(String[]args)
	{
	int a;
	System.out.pintln(a);
}

}