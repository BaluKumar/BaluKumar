import java.util.*;
import java.io.*;
import java.math.*;




class Outcome {

    /*
     * Implement method/function with name 'solve' below.
     * The function accepts following as parameters.
     *  1. number is of type int.
     * return String.
     */

    public static String solve(int number){
        //Write your code here
        String value="";
        if(len(number)==1){
        String [] name ={"One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
        switch(number){
            case 1:value=name[0];
            break;
            case 2:value=name[1];
            break;
            case 3:value=name[2];
            break;
            case 4:value=name[3];
            break;
            case 5:value=name[4];
            break;
            case 6:value=name[5];
            break;
            case 7:value=name[6];
            break;
            case 8:value=name[7];
            break;
            case 9:value=name[8];
            break;
            default :value="Zero";
        }
        }
        else if(len(number)==2&& number<21){
            switch(number){
                case 11:value="eleven";
                break;
                case 10:value="ten";
                break;
                case 12:value="twelve";
                break;
                case 13:value="thirteen";
                break;
                case 14:value="fourteen";
                break;
                case 15:value="fifteen";
                break;
                case 16:value="sixteen";
                break;
                case 17:value="seventeen";
                break;
                case 18:value="eighteen";
                break;
                case 19:value="ninteen";
                break;
                case 20:value="twenty";
                
            }
        }else
        if(len(number)==2 && number>20){
           value=twonum(number);
        }else if(len(number)==3){
            
            String [] name ={"One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
        switch(number/100){
            case 1:value=name[0];
            break;
            case 2:value=name[1];
            break;
            case 3:value=name[2];
            break;
            case 4:value=name[3];
            break;
            case 5:value=name[4];
            break;
            case 6:value=name[5];
            break;
            case 7:value=name[6];
            break;
            case 8:value=name[7];
            break;
            case 9:value=name[8];
            break;
        }
        value=value+" hundred and";
        int ltwo=number-((number/100)*100);
        value=value+twonum(ltwo);
        }
        return value; //return type "String".
    }
    public static int len(int n){
        int count=0;
        
        while(n>0){
            count++;
            n/=10;
        }
        return count;
    }
    public static String twonum(int number){
        String value="";
        String []fname={"twenty","thirty","forty","fifty","Sixty","seventy","eighty","ninety"};
            String [] name ={"One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
            
            int lnum=number%10;
            switch(number/10){
            case 2:value=fname[0];
            break;
            case 3:value=fname[1];
            break;
            case 4:value=fname[2];
            break;
            case 5:value=fname[3];
            break;
            case 6:value=fname[4];
            break;
            case 7:value=fname[5];
            break;
            case 8:value=fname[6];
            break;
            case 9:value=fname[7];
        }
        switch(lnum){
            case 1:value=value+name[0];
            break;
            case 2:value=value+name[1];
            break;
            case 3:value=value+name[2];
            break;
            case 4:value=value+name[3];
            break;
            case 5:value=value+name[4];
            break;
            case 6:value=value+name[5];
            break;
            case 7:value=value+name[6];
            break;
            case 8:value=value+name[7];
            break;
            case 9:value=value+name[8];
        
        }
        return value;
    }

}

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(System.getProperty("OUTPUT_FILE_PATH")));
        bufferedWriter.write("\n");
        bufferedWriter.close();
        bufferedWriter = new BufferedWriter(new FileWriter(System.getProperty("OUTPUT_FILE_PATH"),true));
        int number = Integer.parseInt(bufferedReader.readLine().trim());

        String outcome = Outcome.solve(number);

        bufferedWriter.write(outcome + "\n");

        bufferedWriter.newLine();

        bufferedReader.close();
        bufferedWriter.close();
    }
}
