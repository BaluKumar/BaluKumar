import java.util.Scanner;
public class numToWord {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        String str=Integer.toString(n);
        int len=str.length();
        String word="";
        switch (len) {
            case 1:word+=singleValue(n);
                break;
            case 2:word+=twoDigitValue(n);
                break;
            case 3:word+=singleValue(n/100);
                word+=" hundred and ";
                if (n%100>9) {
                    word+=twoDigitValue(n%100); 
                } else {
                    word+=singleValue(n%10);
                }
            break;
            case 4:word+=singleValue(n/1000);
                word+=" thousand ";
                int a=n%1000;
                if (a/100!=0) {
                    word+=singleValue(a/100);
                    word+=" hundred and ";
                }
                if (a%100>9) {
                    word+=twoDigitValue(a%100); 
                } else {
                    word+=singleValue(a%10);
                }
                break;
            default: word+="outboundry";
        }
        System.out.println(word);
    }
    public static String singleValue(int n) {
        String s[]={"one","two","three","four","five","six","seven","eight","nine"};
        if(n==0){
            return "zero";
        }
        return s[n-1];
    }
    public static String twoDigitValue(int n) {
        if(n<20){
            String s[]={"ten","eleven","twelve","thirteen","fourteen","fifteen","sixteen","seventeen","eighteen","nineteen"};
            return s[n%10];
        }else if (n>=20) {
            String s1[]={"Twenty ","Thirty ","Forty ","Fifty ","Sixty ","Seventy ","Eighty ","Ninety "};
            if (n%10 != 0) {
                return s1[(n/10)-2]+singleValue(n%10);
            }
            return s1[(n/10)-2];
        }
        return "what the heck";
    }
}
