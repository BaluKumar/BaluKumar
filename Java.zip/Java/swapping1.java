// Swapping three number 
import java.util.Scanner;
class swapping1
  {
      public static void main(String []x)
         {
             Scanner s= new Scanner(System.in);
             int a,b,c,i=1;
             a=s.nextInt();
             b=s.nextInt();
             c=s.nextInt();
             System.out.println(a+" "+b+" "+c);
             while(i<=3){
             a=a+b+c;
             b=a-(b+c);
             c=a-(b+c);
             a=a-(c+b);
            System.out.println("Result of Swapping:"+i);
            System.out.println(a+" "+b+" "+c);
            i++;
            }
         }

  }