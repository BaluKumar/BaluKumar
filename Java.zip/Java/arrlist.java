import java.util.ArrayList;
class arrlist
{
  public static void main(String[] args)
      {
         int a[]={10,20,30,80,40,85,88,45};
         ArrayList<Integer>arrlist=new ArrayList<Integer>();
         for(int i=0;i<a.length;i++)
             {
                 arrlist.add(Integer.valueOf(a[i]));
             }
               System.out.println(arrlist);
      }
}