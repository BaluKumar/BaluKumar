import java.util.Scanner;
public class balukali
{
  public static void main(String a11[])
{ 
  int m1,m2,m3,tot,temp;
  char grade;
  String name;
  Scanner S1=new Scanner (System.in);
  m1=S1.nextInt();
  m2=S1.nextInt();
  m3=S1.nextInt();
  name=S1.next();
  tot=m1+m2+m3;
  temp=tot/3;
if ((temp>=80)&&(temp<=100))
          grade='A';
   else if ((temp>=70)&&(temp<=89))
          grade='B';
   else if ((temp>=60)&&(temp<=69))
         grade='C';
   else if ((temp>=50)&&(temp<=59))
        grade='D';
   else if ((temp>=40)&&(temp<=49))
        grade='E';
   else 
         grade='F';
System.out.print("The person"+name+"grade is "+grade);
  }
}