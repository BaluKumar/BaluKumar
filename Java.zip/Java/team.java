import java.util.Scanner;
class team1
{
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		int n=3,res=0;
		int i,j,flag=0,c;
		String s[]=new String[n];
		for(i=0;i<n;i++)
		{
			s[i]=sc.nextLine();
			System.out.println(i);
		}
		for(i=0;i<s.length-1;i++)
		{
			c=Integer.parseInt(s[i]+s[i+1]);
			int k=c;
			for(j=2;j<k;j++)
			{
				if(k%j==0)
					flag++;
			}
			if(flag==0)
				System.out.println(k);
			else
			{
				flag=0;
				for(j=k;j>0;)
				{
					res=(res*10)+(j%10);
					j=j/10;
				}
				for(j=2;j<res;j++)
				{
					if(res%j==0)
						flag++;
				}
				if(flag==0)
					System.out.println(res);
				else
				{
					for(j=2;j<k;j++)
					{
						if(k%j==0)
						System.out.print(j+" ");
					}	
					System.out.println();
				}
			}
			flag=0;
		}
	}
}
/*
take n*n matrix print the matrix in colock wise direction
	sample input
	5 3 1
	4 6 7
	9 8 2
	
	output
	1 2 3 
	8 9 4
	7 6 5
*/
class team2
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int n=3;
		int ca[]=new int[n*n];
		int a[][]=new int[n][n];
		int i,j,k=0;
		for(i=0;i<n*n;i++)
		{
			ca[i]=s.nextInt();
		}
		for(i=0;i<(n*n)-1;i++)
		{
			for(j=i+1;j<n*n;j++)
			{
				if(ca[i]>ca[j])
				{
					ca[i]=ca[i]+ca[j]-(ca[j]=ca[i]);
				}
			}
		}
		i=0;
		for(j=0;j<n;j++)
			{
				a[i][j]=ca[k];
				k++;
			}
			j--;
			for(i=1;i<n;i++)
			{
				a[i][j]=ca[k];
				k++;
			}
			i--;
			for(j=j-1;j>=0;j--)
			{
				a[i][j]=ca[k];
				k++;
			}
			j++;
			for(i=i-1;i>0;i--)
			{
				a[i][j]=ca[k];
				k++;
			}
			i++;
			a[1][1]=ca[k];
		System.out.println("----------Result------------");
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
	}
}
/*
	question asked in interview
*/