import java.util.Scanner;
class  Balu
{public static void main(String[]args)
{
int m1,m2,m3,total;
float avg;
Scanner a= new Scanner(System.in);
m1=a.nextInt();
m2=a.nextInt();
m3=a.nextInt();
total=m1+m2+m3;
avg=total/3;
System.out.println("Total:"+total);
System.out.println("Average:"+avg);
}
}


	