class HI
{
 public static void main(String arg[])
{
  kali();
 }
static void kali()
{
 int S1=20,S2=30,S3;
 S3=S1+S2;
System.out.print("the result is"+S3);
  }
}