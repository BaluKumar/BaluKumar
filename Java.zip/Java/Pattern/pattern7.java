/*Design a method to print given pattern

1*0*1
1*0*1
1*0*1
1*0*1
1*0*1
*/
import java.util.Scanner;
/**
 * pattern7
 */
public class pattern7 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        int n=sc.nextInt();
        for (int i = 0; i < n; i++) {
            int k=1;
            for (int j = 0; j < n; j++) {
                if (j%2==1) {
                    System.out.print("*");
                } else {
                    if (k<0) {
                        k=1;
                    }
                    System.out.print(k--);
                }
            }
            System.out.println();
        }
    }
}