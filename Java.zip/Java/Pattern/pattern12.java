/*Design a method to print given pattern
1
01
010
1010
10101
*/
import java.util.Scanner;
/**
 * pattern12
 */
public class pattern12 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        int n=sc.nextInt();
        int ch=1;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                if (ch<0) {
                    ch=1;
                }
                System.out.print(ch--);
            }System.out.println();
        }
    }
}