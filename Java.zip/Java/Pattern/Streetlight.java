import java.util.Scanner;
class Streetlight{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int N=s.nextInt();
        int a[][]=new int[N][2];
        for(int i=0;i<N;i++){
            a[i][0]=s.nextInt();
            a[i][1]=s.nextInt();
        }
        s.close();
        int sum=0;
        int diff=0;
        for(int i=0;i<N;i++){
            if (a[i][0]<a[i][1]) {
                sum+=(a[i][0]-a[i][1]);
            } else {
                sum+=(a[i][1]-a[i][0]);
            }
            if (i!=N-1) {
                if ((a[i][1]<a[i+1][0])) {
                    diff+=(a[i][1]-a[i+1][0]);
                } else {
                    diff+=(a[i+1][0]-a[i][1]);
                }
            }
        }
        sum=-(sum);
        diff=-(diff);
        int result=sum-diff;

        if (result<0) {
            result=-(result);
            System.out.print(result);
        } else {
            System.out.print(result);
        }
        
    }
}