/*Design a method to print given pattern
1
23
456
7891
23456
*/
import java.util.Scanner;
/**
 * pattern10
 */
public class pattern10 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        int n=sc.nextInt();
        int ch=1;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                if (ch>9) {
                    ch=1;
                }
                System.out.print(ch++);
            }System.out.println();
        }
    }
}