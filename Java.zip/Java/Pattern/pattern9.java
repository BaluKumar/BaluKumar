/*Design a method to print given pattern
A
BC
DEF
GHIJ
KLMNO
*/
import java.util.Scanner;
/**
 * pattern9
 */
public class pattern9 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        int n=sc.nextInt();
        char ch='A';
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print(ch++);
            }System.out.println();
        }
    }
}