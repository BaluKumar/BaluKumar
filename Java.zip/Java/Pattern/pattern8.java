/*Design a method to print given pattern
ABCDE
ABCDE
ABCDE
ABCDE
ABCDE
*/
import java.util.Scanner;
/**
 * pattern8
 */
public class pattern8 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        int n=sc.nextInt();
        for (int i = 0; i < n; i++) {
            char ch='A';
            for (int j = 0; j <n; j++) {
                System.out.print(ch++);
            }System.out.println();
        }
    }
}