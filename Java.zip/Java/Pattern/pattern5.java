/*/*Design a method to print given pattern

12345
67891
23456
78912
34567
*/
import java.util.Scanner;
/**
 * pattern5
 */
public class pattern5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        int n=sc.nextInt();
        int k=1;
        for (int i = 0; i <n; i++) {
            for (int j = 0; j <n; j++) {
                if(k>9)
                k=1;
                System.out.print(k++);
            }
            System.out.println();
        }
    }
}