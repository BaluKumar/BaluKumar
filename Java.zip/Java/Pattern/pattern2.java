/*Design a method to print given pattern
* * * * *
* * * *
* * * 
* *
*
*/
import java.util.Scanner;
/**
 * pattern2
 */
public class pattern2 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        int n=sc.nextInt();
        for(int i=n;i>=0;i--)
        {
            for (int j = i; j>=0; j--)
            {
                System.out.print("* ");
            }System.out.println();
        }
    }    
}