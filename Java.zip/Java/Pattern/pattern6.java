/*Design a method to print given pattern

1*1*1
0*0*0
1*1*1
0*0*0
1*1*1
*/
import java.util.Scanner;
/**
 * pattern6
 */
public class pattern6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        int n=sc.nextInt();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if(j%2==1)
                {
                    System.out.print("*");
                }else
                if (i%2==0) {
                    System.out.print("1");
                } else {
                    System.out.print("0");
                }
            }
            System.out.println();
        }
    }
}