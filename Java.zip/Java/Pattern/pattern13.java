/*Design a method to print given pattern
1
3 2
4 5 6
10 9 8 7
*/
import java.util.Scanner;
/**
 * pattern13
 */
public class pattern13 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size");
        int n=sc.nextInt();
        int k=1;
        int a=0;
        for (int i = 0; i < n; i++) {
            a=i+k;
            for (int j = 0; j <= i; j++) {
                if(i%2==0)
                System.out.print(k+" ");
                else{
                    System.out.print(a--+" ");
                }
                k++;
            }System.out.println();
        }
    }
}