class Banck
{
private long acnum;
long get Acnum()
	{return acnum;

}
private String cusname;
String get Name()
	{return cusname;
	
}
private double bal;
double get Bal()
	{
	return bal;
}
Banck()
{}
Banck(long acnum)
	{this();
	this.acnum=acnum;
}
Banck long acnum,String(Name)
	{
	this(acnum);
	cusname=cName;
}
Banck(long acnum,String cusname,double bal)
	{
	this(acnum,cusName)
	this.bal=bal;
}
void display()
	{
	System.out.println("Account number="+acnum);
	System.out.println("customer name="+cusname);
	System.out.println("Balance="+bal);
}
void deposit(double bal)
	{
	if(bal>0)
	{
	this.bal=bal;
}else
System.out.println("Balance Should be>0");
}
void with draw (double_bal)
	{
	if(this.bal>=bal)
	{
	this.bal=bal;
}else
System.out.println("insuffcient balance");
}
}