import java.util.Scanner;
 class BaluR
{
public static void main(String[]args)
{
int i,a,b,c=0;
Scanner s=new Scanner(System.in);
a=s.nextInt();
b=s.nextInt();
for(i=0;i<b;i++)
{
c=c+a;
}
System.out.println(c);
}
}