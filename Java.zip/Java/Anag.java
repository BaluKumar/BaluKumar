import java.util.Scanner;
/**
 * Anag
 */
public class Anag {

    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String res="",input=s.nextLine();
        s.close();
        char c[]=input.toCharArray();
        int count=1;

        for (int i = 0; i < c.length-1; i++) {
            if (c[i]!='0') {
                for (int j = i+1; j < c.length; j++) {

                    if (c[i]==c[j]) {
                        count++;
                        if(count==2){
                            res=res+ch[j];
                        }else if(count)
                        c[j]='0';
                    }
                }
                System.out.println(count);
    
                count=1;   
            }
        }
    }
}