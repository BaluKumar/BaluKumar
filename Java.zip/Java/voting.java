import java.util.Scanner;
class voting
{
	public static void main(String args[])
	{
		int a;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter your age");
		a=sc.nextInt();
		if(a>18)
		System.out.println(a +"Is eligible for voting");
		else
		System.out.println(a +"Is non elegible for voting");
	}
}
		