//write a program to find age difference between two person
class Agediff
{
      public static void main(String []args)
         {
            int a=Integer.parseInt(args[0]);
            int b=Integer.parseInt(args[1]);
            int z=a-b;
            if (z<0)
	z=-z;
           System.out.println(z);
       }
}