import java.util.Scanner;
class skin
{
    public static void  main(String []args) 
    {
        Scanner S=new Scanner(System.in);
        int n=S.nextInt();
        int b=S.nextInt();
        int c=n+b;
        System.out.println(c);
        
    }
}