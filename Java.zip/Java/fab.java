//Program to print fabonic first n values
import java.util.Scanner;
class fab
 {
    public static void main(String []args)
       {
         Scanner s=new Scanner(System.in);
         int x=s.nextInt();
         int a=-1,b=1,c=0,count=0;
         for(int i=0;i<=x;i++)
	{
	 c=a+b;
	 a=b;
	 b=c;
	 System.out.print(c+"  ");
	}
       }
 }