/*
*/
import java.util.Scanner;
class Base1
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int n;
		System.out.println(" 1.Addtion"+"\n 2.Subraction"+"\n 3.Multiplication"+"\n 4.Division"+"\n 5.Modulos");
		do
		{
			System.out.println("\t\t Select witch operation are you going to do");
			int p=s.nextInt();
			System.out.println("Enter two value to do the Calculation:");
			int a=s.nextInt();
			int b=s.nextInt();
		
			switch(p)
			{
				case 1:System.out.print("Addtion of a&b is:"+(a+b));
			       break;
				case 2:System.out.print("Subraction of a&b is:"+(a-b));
			       break;
				case 3:System.out.print("Multiplication of a&b is:"+(a*b));
			       break;
				case 4:System.out.print("Division of a&b is:"+(a/b));
			       break;
				case 5:System.out.print("Modulos of a&b is:"+(a%b));
			       break;
				default:System.out.print("Select the operation with in 1to5:");
			}
		System.out.println("\n Do you wish to continue or not\n if yes type '0' if no type '1' ");
		n=s.nextInt();
		}while(n==0);
	}
}

/*

*/
class Base2
{
	public static void main(String [] args)
	{
		Scanner sc = new Scanner (System.in);
    
    int n=sc.nextInt();
    int v[]= new int[n];
    int x=sc.nextInt();
   
    for(int i=0; i<n; i++)
       v[i]=sc.nextInt();
    
    for(int i=0;i<n;i++){
        v[i]=(v[i]-1)/x;
        
    }
    
    int m=0, maxPos=0;
    
    for(int i=0;i<n;i++){
        
        if(v[i]>=m){
            m=v[i];
            maxPos=i;
        }
    }
    
    System.out.println(maxPos+1);
	}
}
/*
*/
class Base3
{ 
  public static void main(String args[])
  {
    Scanner s=new Scanner(System.in);
	int a[]={5,9,6,3,7,8};
	int c;
	for(int i=0;i<6;i++)
	{
		for(int j=i+1;j<6;j++)
		{
			if(a[j]>a[i])
			{
				c=a[i];
				a[i]=a[j];
				a[j]=c;
			}
		}
	}
	for(int k=0;k<6-1;k++)
	{
		if(a[k]>a[k+1])
		{
			System.out.println(a[k+1]);
			break;
		}
	}
  }
}
 /*replace char where letter 'c' in college into 'd' 
 */
class Base4
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		String name=s.nextLine(),n1="";
		char c1=s.next().charAt(0);
		/*we cant use nextChar(). in scanner file there no nextChar() class
		.so, we use "next().charAt(0)" this comand to get char value from the user */
		char c2=s.next().charAt(0);
		int n=name.length();
		for(int i=0;i<n;i++)
		{
			if(c1==name.charAt(i))
				n1=n1+c2;
			else
				n1=n1+name.charAt(i);
		}
		System.out.print(n1);
		
	}
}
/* 
*/
class Base5
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("hi,how are you");
		s.close();/*if we use "close" method in scanner we cant use 
		scanner method again in this class even if we 
		create new scanner object in this method 
		"we can create scanner object even after 
		close method. but we can't  use the scanner object"
		it will throw exception error in "runtime". 
		but not in "compile time"*/
		//int i=s.nextInt();// --> exception  error
	}
}
/*

*/
class Base64
{
	public static void main(String [] args)
	{
		if(true)
		{
			//break;
			/*we can't use break statement outside the loop	or switch.
			we can use break statement even inside 
			the if statement only if statement present inside
			the loop or switch case
			------------------------------
			Example:
class IterationControl5 
{
	public static void main(String[] args) {
		// The below code generates customerId
		int totalNoOfCustomers = 12;
		String customerId = "";
		for (int counter = 1; counter <= totalNoOfCustomers; counter++) {
			if (counter <= 9)
			{
				customerId = "C0" + counter;
				break;
			}
			else
				customerId = "C" + counter;
			System.out.println("Customer Id for customer " + counter + " is "
					+ customerId);
		}
	}
}
----------------------------------
			*/
			System.out.println("Hii!!!!");
			
		}
	}
}

