import java.util.LinkedList;
import java.util.Scanner;
//prime and factorial
class methodPrime{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the value:");
        int a=s.nextInt();
        System.out.println("1.To check prime number from 1 to "+a);
        System.out.println("2.To check "+a+" is prime number or not");
        System.out.println("3.To check Factorial number from 1 to "+a);
        System.out.println("4.To check "+a+" is prefect number or not");
        int cas=s.nextInt();
        s.close();
        switch (cas) {
            case 1:System.out.println(NthPrime(a));
                break;
            case 2:System.out.println(isPrime(a));
            if(isPrime(a)!=0){
            break;}else{
            System.out.println(a+" has more than two factors they are:");
            }
            case 3:System.out.println(NthFactorial(a));
            break;
            case 4:prefectNumber(a);
            break;
            case 5:System.out.println(NthPrefectNumber(a));
        }
        
    }
    public static void prefectNumber(int a){
        int sum=0;
        for (int i = 1; i < a; i++) {
            if (a%i==0) {
                sum+=i;
            }
        }
        if (sum==a) {
            System.out.println(a+" is a Prefect Number");
        }else{
            System.out.println(a+" is not a Prefect Number");
        }
    }
    public static int isPrime(int a){
        boolean flag=true;
        for (int j = 2; j < a; j++) {
            if(a%j==0){
                flag=false;
            }
        }
        if (flag) {
            return a;
        } else {
            return 0;
        }
    }
    public static LinkedList NthPrime(int a){
        LinkedList<Integer> l=new LinkedList<Integer>();
        for (int i = 2; i <=a; i++) {
            boolean flag=true;
            for (int j = 2; j <i; j++) {
                if(i%j==0){
                    flag=false;
                }
            }
            if(flag){
                l.add(i);
            }
        }
        return l;
    }
    public static LinkedList NthFactorial(int a){
        LinkedList<Integer> l=new LinkedList<Integer>();
        for (int j = 1; j < a; j++) {
            if(a%j==0){
                l.add(j);
            }
        }//System.out.println(l);
        return l;
    }
    public static LinkedList NthPrefectNumber(int a) {
        LinkedList<Integer> l=new LinkedList<Integer>();
        for (int i = 2; i <= a; i++) {
            int sum=0;
            for (int j = 1; j < i; j++) {
                if (i%j==0) {
                    sum+=j;
                }
            }
            if (sum==i) {
                l.add(i);
            }
        }
        return l;
    }
}