//methodoverloading with subString(i)
import java.util.Scanner;
class subString
{
   String str;
   public void getstr()
       {
           Scanner ss=new Scanner(System.in);//wittlowry song
           str=ss.nextLine();
       }
   public void substr(int a,int b)
       {
           for(int i=a;i<b;i++)
             System.out.println(str.charAt(i)) ;    
       }
   public void substr(int x)
        {
            for(int i=x;i<str.length();i++)
	System.out.print(str.charAt(i));
        }
   public static void main(String [] args)
        {
             subString s=new subString();
             Scanner ss=new Scanner(System.in);
             int i1,i2;
             i1=ss.nextInt();
             i2=ss.nextInt();
             s.getstr();
             s.substr(i1,i2);
             s.getstr();
             i1=ss.nextInt();
             s.substr(i1);

        }
}