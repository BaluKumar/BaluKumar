class mo
{
  public static void main(String [] args)
  {
     int a,b,c;
	 a=10;
	 b=52;
	 c=a+b;
	 System.out.println(c);
  }
}