class Methods
{
	public static void add()
	{
		System.out.println("Hii");
		Methods m=new Methods();
		m.sub();
	}
	public void sub()
	{
		System.out.println("goodbye");
	}
}