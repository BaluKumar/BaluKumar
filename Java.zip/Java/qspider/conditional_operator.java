class conditional_operator
{
	public static void main(String[]args)
	{
	int a=10;
	int b=20;
	int c=30;
	int d=(a<b?a:b)>(b<c?b:c)?(a<b?a:b):(b<c?b:c);
	System.out.println(c);
	}
}