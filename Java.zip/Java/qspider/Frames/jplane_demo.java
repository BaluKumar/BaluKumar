import javax.swing.*;
import java.awt.*;
class jplane_demo
{
	public static void main(String [] args)
	{
		JFrame f=new JFrame();
		f.setTitle("Title");
		f.setResizable(false);
		ImageIcon i=new ImageIcon("music-logo2.jpg");
		f.setIconImage(i.getImage());
		f.getContentPane().setBackground(new Color(0255,255,255));//-->to set color of the window
		//new Color(0,0,0) or Color.color_name
		JTextField t=new JTextField("                     ");
		JToolBar TB=new JToolBar();
		t.setSize(80,50);
		f.setSize(600,400);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel p=new JPanel();
		JButton b=new JButton("Button1");
		JLabel lab=new JLabel("Lable1");
		p.add(TB);
		p.add(t);
		p.add(b);
		p.add(lab);
		f.add(p);
	}
}