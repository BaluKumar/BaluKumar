import javax.swing.*;
class JFrame_p1
{
	public static void main(String [] args)
	{
		JFrame frames=new JFrame("ScrollBar");
		//frames.setLayout(new FlowLayout());
		JTextArea JT=new JTextArea(10,15);
		
		
		frames.add(JT);
		frames.setSize(400,300);
		frames.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frames.setVisible(true);
	}
}