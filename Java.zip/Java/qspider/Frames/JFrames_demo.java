//my first jframe program
import javax.swing.*;
public class JFrames_demo
{
	public static void main(String [] args)
	{
		JFrame JF=new JFrame("First Frame");
		JF.setSize(300,300);
		JF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JF.setLayout(null);
		JF.setVisible(true);
	}
	
}