import java.util.Scanner;
class p2
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		char st='g';
		char ed='m';
		char a=st;
		System.out.println("Character between "+st+" to "+ed);
		while(a>=st&&a<=ed)
		{
			System.out.println(a);
			a++;
		}
		
	}
}