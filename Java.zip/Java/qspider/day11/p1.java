class p1
{
	public static void main(String[] args)
	{
		int a=5;
		System.out.println("the numbers are: ");
		while(a>=5&&a<=10)
		{
			System.out.println(a);
			a++;
		}
	}
}