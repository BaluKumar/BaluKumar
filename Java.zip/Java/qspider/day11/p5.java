import java.util.Scanner;
class p5
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the starting Character :");
		char a=s.next().charAt(0);
		System.out.println("Result values:");
		while(a>='m'&&'n'>=a)
		{
			System.out.println(a);
			a++;
		}
	}
}