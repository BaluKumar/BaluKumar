class p3
{
	public static void main(String[] args)
	{
		String name="Balu";
		int age=20,i=0;
		System.out.println("Entering the name and age  "+age+"times");
		while(i<age)
		{
			System.out.println(name+"\n"+age);
			i++;
		}
	}
}