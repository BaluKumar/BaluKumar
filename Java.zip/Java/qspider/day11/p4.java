import java.util.Scanner;
class p4
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		char st=s.next().charAt(0);
		char ed=s.next().charAt(0);
		char a=st;
		System.out.println("Character between "+st+" to "+ed);
		while(a>=st&&a<=ed)
		{
			System.out.println(a);
			a++;
		}
		
	}
}