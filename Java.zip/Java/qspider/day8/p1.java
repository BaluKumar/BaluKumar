import java.util.Scanner;
class p1
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the product Name:");
		String product_Name=s.next();
		System.out.println("Enter price Amount:");
		double price=s.nextDouble();
		System.out.println("Enter quantity:");
		int qty=s.nextInt();
		double total=price*qty;
		double discount_amount;
		if(qty<=2)
		{
			System.out.println("discount is not avilable");
			System.out.println("Product Name: "+product_Name);
			System.out.println("Amount to be paid: "+"  Rs:"+total);
		}else if(qty>=3&&6>=qty)
		{
			System.out.println("10% discount is avilable");
			System.out.println("Product Names: "+product_Name);
			System.out.println("Total Amount:"+total);
			discount_amount=total*10.0/100;
			total=total-discount_amount;
			System.out.println("discount Amount:"+discount_amount);
			System.out.println("Amount to be paid:"+"  Rs:"+total);
		}else if(qty>=7&&9>=qty)
		{
			System.out.println("15% discount is avilable");
			System.out.println("Product Names: "+product_Name);
			System.out.println("Total Amount:"+total);
			discount_amount=total*15.0/100;
			total=total-discount_amount;
			System.out.println("discount Amount:"+discount_amount);
			System.out.println("Amount to be paid:"+"  Rs:"+total);
		}else if(qty>10)
		{
			System.out.println("25% discount is avilable");
			System.out.println("Product Names: "+product_Name);
			System.out.println("Total Amount:"+total);
			discount_amount=total*25.0/100;
			total=total-discount_amount;
			System.out.println("discount Amount:"+discount_amount);
			System.out.println("Amount to be paid:"+"  Rs:"+total);
		}
		System.out.println("		\t\t\t***********************");
		System.out.println("		\t\t\t*Thank you, Come Again*");
		System.out.println("		\t\t\t***********************");
	}
}