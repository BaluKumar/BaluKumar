class conditional_operator1
{
	public static void main(String[]args)
	{
	int a=10;
	int b=0;
	int d=(a%2==0)?a:b;
	System.out.println(d);
	}
}