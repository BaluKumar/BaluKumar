class P1
{
	public static void main(String [] args)
	{
		System.out.println("Name: Balu");
		System.out.println("Age: 20");
	}
}