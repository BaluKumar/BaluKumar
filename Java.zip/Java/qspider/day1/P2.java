class P2
{
	public static void main(String [] args)
	{
		System.out.println("Age: 20");
	}
}