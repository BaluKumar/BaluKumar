class p5
{
	public static void main(String [] args)
	{
		int a=080;
		System.out.println(a);
	}
}