class p2
{
	public static void main(String [] args)
	{
		int i=15;
		System.out.println(i++);
		System.out.println(i--);
	}
}