class p6
{
	public static void main(String [] args)
	{
		int a=200;
		String s=String.valueOf(a);
		System.out.println(a+100);
		System.out.println(s+100);
	}
}