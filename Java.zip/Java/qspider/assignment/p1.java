class p1
{
	public static void main(String [] args)
	{
		if(True)//boolean value should be in lower case
			System.out.println("java");
		else 
			System.out.println("Javas");
	}
}