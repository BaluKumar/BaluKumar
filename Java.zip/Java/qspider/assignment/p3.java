import java.util.Scanner;
class p3
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int res=0;
		do
		{
			res=(res*10)+(n%10);
			n=n/10;
			
		}while(n>9);
		System.out.println("reverse of n:"+res);
	}
}