import java.util.Scanner;
class p2
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Integer value:");
		int a=s.nextInt();
		if(a%5==0&&a%9==0)
		{
			System.out.println(a+" is divisable by both 5 and 9");
		}else
			System.out.println(a+" is not divisable by both 5 and 9");
	}
	
}