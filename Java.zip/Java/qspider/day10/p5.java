import java.util.Scanner;
class p5
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter Integer value :");
		int a=s.nextInt();
		int res=a%10;
		System.out.println(res);
	}
}