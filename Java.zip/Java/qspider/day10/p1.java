import java.util.Scanner;
class p1
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value:");
		char ch=s.next().charAt(0);
		if(ch>='A'&&ch<='Z')
		{
			System.out.println(ch+" is a upper case alphabet");
		}
		else if(ch>='a'&&ch<='z')
		{
			System.out.println(ch+" is a lower case alphabet");
		}
		else if(ch>='0'&&ch<='9')
		{
			System.out.println(ch+" is a digit");
		}
		else
			System.out.println(ch+" is a special Character");
	}
}