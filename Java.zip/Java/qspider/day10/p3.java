import java.util.Scanner;
class p3
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value");
		int a=s.nextInt();
		switch(a)
		{
			case 1:System.out.println("Holiday");
			break;
			case 2:System.out.println("Cricket");
			break;
			case 3:System.out.println("Foot Ball");
			break;
			case 4:System.out.println("Tennis");
			break;
			case 5:System.out.println("Basket Ball");
			break;
			case 6:System.out.println("Cricket");
			break;
			case 7:System.out.println("Foot Ball");
			break;
			default :System.out.println("invalid week number");
		}
	}
}