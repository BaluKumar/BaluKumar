class A
    {
     String s="S1";
     public void m1()
   { 
      System.out.print("hi");
       }
    }
class B extends A
    {
     String t="S2";
     public void m2()
   { 
      System.out.print("hello");
       }
    }
class C
    {
     public static void main(String args [])
     A.a=new B();
    System.out.println(a.s + "\n" + a.t);
    a.m1();
    a.m2();
      }
       
    