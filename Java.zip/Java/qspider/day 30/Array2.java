import java.util.Scanner;
class Array2 
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Size of Array");
		int n=s.nextInt();
		char a[]=new char[n];
		int count=0;
		System.out.println("Enter the values");
		for (int i=0;i<n;i++ )
		{
			a[i]=s.next().charAt(0);
		}
		for(int i=0;i<n;i++) 
		{
			if('a'<=a[i]&&a[i]<='z')
			{
				count++;
			}
			System.out.print(a[i]);
		}
		int rem=n-count;
		System.out.print("\nNo.lowerCase : "+count+" No.UpperCase "+rem);
	}
}
