import java.util.Scanner;
class timesec
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
	    System.out.println("Enter the meter  :");
		int meter=s.nextInt();  //34545 m
		//System.out.println("Enter the km   :");
		//int km=s.nextInt(); // 54 km
		int km = meter/1000;
		meter =meter%1000;
		System.out.print(km+" km  " + meter +" meters");
	}
}
