import java.util.Scanner;
class timedemo
{
	public static void main(String []args)
	{
   		Scanner s=new Scanner(System.in);
		System.out.println("Enter the meters   : ");
		int meter=s.nextInt();//654125
		int km=meter/1000;
		meter=meter%1000;
		System.out.println(km + " km "+meter +" meter ");

	}
}
//
