import java.util.Scanner;
class Leap
{
 public static void main(String []args)
{
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter tha value");
  int year=sc.nextInt();
  if (year%4==0)
{
 System.out.println("leap year"+year);
 }
 else
System.out.println(year+"not a leap year");
 }
}