class ola
{
	String name;
	long ph_no;
	ola(String name,long ph_no)
	{
		this.name=name;
		this.ph_no=ph_no;
	}
	ola()
	{
		
	}
}
	