class mini extends ola
{
	int kmp=10;
	int hkm;
	mini(String name,long ph_no,int hkm)
	{
		this.name=name;
		this.ph_no=ph_no;
		this.hkm=hkm;
	}
	mini()
	{
		
	}
	public void price()
	{
		System.out.println("total price"+kmp*kmp);
	}
 
}