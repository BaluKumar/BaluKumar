class parent
{
public void test ();
System.out.println("From Parent");
}
 }
 class child extends parents
 {
 public void test();
 {
 System.out.println("From Child");
}
public static void main (String[]args);
{
parent P=new child();
parent.test();
  }
 }