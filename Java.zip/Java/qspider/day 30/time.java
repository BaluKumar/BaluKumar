import java.util.Scanner;
class time
{
	static void m1(int sec)
	{
		int min=sec	/60;
		int Sec=sec%60;
		System.out.println(min+"   minutes  "+Sec+"   seconds " );
	}
	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enetr the time");
		int sec=sc.nextInt();
		m1(sec);
	}
}
