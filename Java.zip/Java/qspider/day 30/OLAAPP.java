import java.util.Scanner;
class OLAAPP
{
	public static void main (String [] args)
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter name");
	String name=sc.nextLine();
	System.out.println("Enter ph_no");
	long ph_no=sc.nextLong();
	System.out.println("Enter km");
	int km=sc.nextInt();
	System.out.println("1.mini,2.prime");
	int choice=sc.nextInt();
	switch(choice)
		{
			case 1:mini m=new mini(name,ph_no,km);
			      m.price();
				  break;
		    case 2:prime p=new prime(name,ph_no,km);
			      p.prime();
		}
	}
}