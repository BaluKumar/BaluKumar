class prime extends ola
{
	int kmp=15;
	int hkm;
	prime(String name,long ph_no,int hkm)
	{
		this.name=name;
		this.ph_no=ph_no;
		this.hkm=hkm;
	}
	prime()
	{
		
	}
     public void prime()
	{
		System.out.println("total price"+kmp*kmp);
	}
}
