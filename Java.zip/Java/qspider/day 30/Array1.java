import java.util.Scanner;
class  Array1
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Size of Array");
		int n=s.nextInt();
		int a[]=new int[n];
		System.out.println("Enter the values");
		a=getValue(a,n);
		evenValue(a,n);
	}
	public static void evenValue(int a[],int n)
	{
		int count=0;
		for (int i=0;i<n ;i++ )
		{
			if (a[i]%2==0)
			{
				count++;
				System.out.print(a[i]+" ");
			}
		}
		System.out.println("\n count : "+count);
	}
	public static int[] getValue(int a[],int n) 
	{
		Scanner s=new Scanner(System.in);
		for (int i=0;i<n;i++ )
			a[i]=s.nextInt();
		return a;
	}
}
