import java.util.Scanner;
class arrays10
{
    public static void main(String[]args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=sc.nextInt(),num=0;
        System.out.println("getting the arrays values ");
        int []a=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        for(int j=0;j<n;j++)
        {
            num+=palindrom(a[j]);
        }
        System.out.println(num);
    }
    //check palindrom or not
    public static int palindrom(int a)
    {
        int temp=a,rev=0;
        while(temp!=0)
        {
            rev+=(temp%10);
            temp/=10;
        }
        System.out.println(a+" "+rev);
        if(rev==a)
            return 1;
        return 0;
    }
}