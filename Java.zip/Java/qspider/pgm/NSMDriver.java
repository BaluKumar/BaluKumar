Class NSMDriver
{
	Public static void main(String[]args)
	{
		NSM n=new NSM();
		n add();
	}
}