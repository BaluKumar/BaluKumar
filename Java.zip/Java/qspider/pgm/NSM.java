Class NSM
{
	Public void add()
	int a=50;
	int b=50;
	int c=a=b;
	System.out.println(c);
}