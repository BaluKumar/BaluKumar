import java.util.Scanner;
class p1
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int count=0,a,m,n;
		m=s.nextInt();
		n=s.nextInt();
		while (m<=n)
		{
			if(m%2==0)
			{
				count++;
			}
			m++;
		}
		System.out.println("no.of.Even :"+count);
	}
}