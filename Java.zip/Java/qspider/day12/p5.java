import java.util.Scanner;
class p5
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value:");
		int n=s.nextInt(),i=1;
		while(i<=n)
		{
			if(n%i==0)
				System.out.println("Factors by :"+i+" "+n/i);
			i++;
		}
	}
}