import java.util.Scanner;
class p3
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter which table you need :");
		int n=s.nextInt(),i=1,k;
		while(i<=5)
		{
			k=n*i;
			System.out.println(n+"*"+i+"="+k);
			i++;
		}
	}
}