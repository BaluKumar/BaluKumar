import java.util.Scanner;
class p5
{
	public static void main(String[] args)
	{
		String s="alphabets",s1="",s2="";
		int c=0,v=0,n=s.length(),i=0;
		while(n>i)
		{
			if(s.charAt(i)=='a'||s.charAt(i)=='e'||s.charAt(i)=='i'
			||s.charAt(i)=='o'||s.charAt(i)=='u')
			v++;
			else
				c++;
			i++;
		}
		System.out.println("No.of.Vowels :"+v+"\nNo.of.Consonants :"+c);
	}
}