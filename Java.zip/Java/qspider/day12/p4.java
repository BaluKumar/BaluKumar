import java.util.Scanner;
class p4
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the range :");
		int even=0,odd=0,m,n;
		m=s.nextInt();
		n=s.nextInt();
		while(m<=n)
		{
			if(m%2==0)
			{
				even++;
			}else
			{
				odd++;
			}
			m++;
		}
		System.out.println("no.of.Even: "+even+"\nno.of.Odd: "+odd);
	}
}