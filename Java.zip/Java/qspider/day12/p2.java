import java.util.Scanner;
class p2
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int m,n;
		System.out.println("Enter m and n value");
		m=s.nextInt();
		n=s.nextInt();
		while(m<=n)
		{
			if(m%2==0)
				System.out.print(m+",");
			m++;
		}
	}
}