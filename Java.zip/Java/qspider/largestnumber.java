class largestnumber
{
	public static int Arug(int a,int b,int c)
	{
	int d=(a>b&&a>c)?a:(b>c?b:c);
	System.out.println(d);
	return d;
	}
	public static void main(String[]args)
	{
	System.out.println("largest of three number");
	System.out.println(Arug(5,10,20));
	}
}