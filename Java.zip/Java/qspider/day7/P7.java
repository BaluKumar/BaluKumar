import java.util.Scanner;
class P7
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("First value");
		int a=s.nextInt();
		System.out.println("Second value");
		int b=s.nextInt();
		int largest=a>b?a:b;
		System.out.println("largest value :"+largest);
	}
}