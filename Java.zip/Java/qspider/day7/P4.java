class P4
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter fruit Name");
		String fruit=s.next();
		System.out.println(fruit);
	}
}