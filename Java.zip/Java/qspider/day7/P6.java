import java.util.Scanner;
class P6
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Radius");
		double radius=s.nextInt();
		double area =3.14*radius*radius;
		System.out.println("Area:"+ area);
	}
}