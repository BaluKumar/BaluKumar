import java.util.Scanner;
class P2
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the value ");
		int a=s.nextInt();
		double cube =Math.pow(a,3);
		System.out.println("Cube value :"+ cube);
	}
}