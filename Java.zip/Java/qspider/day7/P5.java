import java.util.Scanner;
class P5
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the sec");
		float sec =s.nextFloat();
		float min=sec/60;
		System.out.println(min);
	}
}