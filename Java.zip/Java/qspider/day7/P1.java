class P1
{
	public static void main(String [] args)
	{
		int dis=750;
		double T=4.5;
		double S=dis/T;
		System.out.println("Speed of Train: "+S);
	}
}