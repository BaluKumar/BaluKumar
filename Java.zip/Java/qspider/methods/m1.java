//addaion , subraction ,multiplication,division,modulous using methods
import java.util.Scanner;
class m1
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int b=s.nextInt();
		System.out.println("1.add,2.sub,3.multiplication,4.division,5.modulous ");
		int c=s.nextInt();
		switch(c)
		{
			case 1:sum(a,b);
			break;
			case 2:sub(a,b);
			break;
			case 3:muli(a,b);
			break;
			case 4:div(a,b);
			break;
			case 5:mod(a,b);
			break;
			default:
			{
				System.out.println("a value :"+a);
				System.out.println("b value :"+b);
			}
		}
	}
	static void sum(int x,int y)
	{
		int z=x+y;
		System.out.println(z);
	}
	static void sub(int x,int y)
	{
		int z=x-y;
		System.out.println(z);
	}
	static void muli(int x,int y)
	{
		int z=x*y;
		System.out.println(z);
	}
	static void div(int x,int y)
	{
		int z=x/y;
		System.out.println(z);
	}
	static void mod(int x,int y)
	{
		int z=x%y;
		System.out.println(z);
	}
}
/*
int nextInt();
char next().charAT(0);
String next();
String nextLine();
short nextShort();
byte  nextByte();
long nextLong();
float nextFloat();
double nextDouble();
*/