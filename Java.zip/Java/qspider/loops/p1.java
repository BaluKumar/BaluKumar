import java.util.Scanner;
class p1
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter the value :");
		int a=s.nextInt();			
	}
}