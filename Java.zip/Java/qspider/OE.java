class OE
{
	public static void main(String[]args)
	{
	int a=11;
	int b=0;
	int d=(a%2!=0)?a:b;
	//System.out.println("even");
	System.out.println(d);
	}
}