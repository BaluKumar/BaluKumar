import java.util.*;
class sample{
    public static void main(String[] args){
        Scanner s=new Scanner(System.in);
         
        System.out.println("Enter the number of Signals : ");
        int Num_of_Signal=s.nextInt();

        
    }
}