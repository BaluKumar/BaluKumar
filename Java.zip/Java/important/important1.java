/*
Input: 1 9 2 8 3 7 4 6 5 10
Explination: 
seperation
odd 1 9 3 7 5
even 2 8 4 6 10

shorting 
even: 2 4 6 8 10
odd: 1 3 5 7 9 

output:2 1 4 3 6 5 8 7 10 9 
*/ 
import java.util.Scanner;
public class important1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value");
        int[]a=new int[10];
        for (int i = 0; i < a.length; i++) {
            a[i]=sc.nextInt();
        }
        int E=0,O=0;
        int[]Even=new int[10];
        int Odd[]=new int[10];
        for (int i = 0; i < a.length; i++) {
            if (a[i]%2==0) {
                Even[E++]=a[i];
            } else {
                Odd[O++]=a[i];
            }
        }
        for (int i = 0; i < Odd.length-1; i++) {
            for (int j = i+1; j < Odd.length; j++) {
                if(Odd[i]>Odd[j]&&Odd[j]!=0)
                Odd[i]=Odd[i]+Odd[j]-(Odd[j]=Odd[i]);
            }
        }
        for (int i = 0; i < Even.length-1; i++) {
            for (int j = i+1; j < Even.length; j++) {
                if(Even[i]>Even[j]&&Even[j]!=0)
                Even[i]=Even[i]+Even[j]-(Even[j]=Even[i]);
            }
        }
        //printting even numbers
        for (int i = 0; i < Even.length; i++) {
            if(i<Even.length&&Even[i]!=0)
            System.out.print(Even[i]+" ");
            if(i<Odd.length&&Odd[i]!=0)
            System.out.print(Odd[i]+" ");
        }
        System.out.println();
        //printting odd number
        for (int i = 0; i < Odd.length; i++) {
            
        }
    }
}
