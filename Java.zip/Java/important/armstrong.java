import java.util.Scanner;
/*Question
case 1:153
O/P
Armstrong
case 2:13
O/P
not Armstrong
 
ex 1:
 n=153,sum=3*3*3+5*5*5+1*1*1=153
 n==sum
 ------------true--------------
 ex 2:
 n=1634,sum=4*4*4*4+ 3*3*3*3 +6*6*6*6+ 1*1*1*1=1634
 n==sum
 --------------true--------------
 ex 3:
 n=14,sum=4*4+ 1*1=17
 n==sum
 --------------false--------------
*/
class armstrong
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int k=m1(n);
		if(k==n)
			System.out.println(n+" Armstrong");
		else
			System.out.println(n+" isn't Armstrong");
	}
	
	public static int m1(int k)
	{
		int sum=0,len=(String.valueOf(k)).length();
		while(k>0)
		{
			int last=k%10;
			k=k/10;
			sum+=Math.pow(last,len);
		}
		return sum;
	}
}