import java.util.Scanner;
class b
{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		String input_from_question=sc.next();
		int count=0;
		for(int i=0;i<input_from_question.length()-1;i++)
		{
			for(int j=i+1;j<input_from_question.length();j++)
			{
				if(input_from_question.charAt(i)==input_from_question.charAt(j))
				{
					count++;
					break;
				}
			}
			if(count==0)
			{
				System.out.println(input_from_question.charAt(i));
				System.exit(0);
			}count=0;
		}
	}
}