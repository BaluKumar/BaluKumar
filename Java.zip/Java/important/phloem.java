import java.util.Scanner;
/*
Question: Phloem
case 1:
input:154
output:154 is a phloem
ex: firstdigit 1+lastdigit 4 is == addition of remaing number
			5                   ==			5
			true
case 2:		
input:34326
output:34326 is a phloem
ex: firstdigit 3+6 lastdigit ==4+3+2 addition of remaing number
9==9
true
case 3:
input:1683
output:1683 isn't a phloem
ex: firstdigit 1+3 lastdigit==6+8 addition of remaing number
4==12
false
*/
class phloem
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		boolean value=m1(n);
		if(value)
			System.out.println(n+" is a phloem");
		else
			System.out.println(n+" is not a phloem");
	}
	public static boolean m1(int n)
	{
		int firstlast=0,rem=0,count=0;
		int len=(String.valueOf(n)).length();	
		while(n>0)
		{
			int last=n%10;
			n=n/10;
			count++;
			if(count==1||count==len)
				firstlast=firstlast+last;
			else
				rem=rem+last;
		}
		if(firstlast==rem)
			return true;
		else
			return false;
	}
}