import java.util.Scanner;
class oldpattern1
{
	public static void main(String [] args)
	{
		int n=7;
		int k=4,i,j;
		for(i=1;i<=k;i++)
		{
			for(j=1;j<=i;j++)
			{
				System.out.print("* ");
			}
			for(int g=0;g<n-i;g++)
			{
				if(g<n-(i*2))
					System.out.print("  ");
				else
					System.out.print("* ");
			}
			System.out.println();
		}
	}
	
}
class oldpattern2
{
	public static void main(String [] args)
	{
		int n=7;//inlization
		int r=4,s=3;
		int i,j;//decleration
		int c=0;
		for(i=1;i<=r;i++)
		{
			for(j=0;j<s;j++)
			{
				System.out.print("  ");
			}
		s--;
		    for(j=0;j<i*2-1;j++)
			{
				System.out.print("* ");
			}
		System.out.println();
		}
	}
}

