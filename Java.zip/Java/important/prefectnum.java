import java.util.Scanner;
class prefectnum
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int e=s.nextInt();
		int sum=0;
		for(int n=0;n<=e;n++)
		{
			for(int i=1;i<=n/2;i++)
			{
				if(n%i==0)
				{
					sum=sum+i;
				}
			}
			if(sum==n)
			{
				System.out.println(n+" is a prefectnumber");
			}
			sum=0;
		}
	}
}