import java.util.Scanner;
class arrayPrime
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int a[]=new int[n];
		for(int i=0;i<n;i++)
			a[i]=s.nextInt();
		System.out.println("******************primeNumbers in Array******************");
		for(int i=0;i<n;i++)
		{
			if(sumPrime(a[i]))
				System.out.print(a[i]+" ");
			
		}
	}
	public static boolean sumPrime(int a)
	{
		int count=0;
		
		for(int j=2;j<a/2;j++)
		{
			if(a%2==0)
				count++;
		}
		if(count==0)
			return true;
		else
			return false;
	}
}