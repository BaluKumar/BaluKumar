import java.util.Scanner;
/*check wheather the given number is Neon or not
9^2 =81  8+1=9
|            |
------==------//check the condition
it a Neon
8^2=64  6+4=10
|            |
------==------//check the condition
isn't Neon
*/
class Neon
{
	public static void main(String[]args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt(),k=n*n,sum=0;
		while(k>0)
		{
			sum+=k%10;
			k/=10;
		}
		if(sum==n)
			System.out.println(n+"is a Neon");
		else
			System.out.println(n+"isn't Neon");
	}
}