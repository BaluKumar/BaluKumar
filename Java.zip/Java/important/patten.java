class patten
{
	public static void main(String [] args)
	{
		int n=1002;
		System.out.println((String.valueOf(n)).length());
	}
}
class patten1
{
	public static void main(String [] args)
	{
		int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}
}
class patten2
{
	public static void main(String [] args)
	{
		int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(i+" ");
			}
			System.out.println();
		}
	}
}
class patten3
{
	public static void main(String [] args)
	{
		int n=5;
		for(int i=n;i>0;i--)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}
}
class patten4
{
	public static void main(String [] args)
	{
		int n=5;
		for(int i=n;i>0;i--)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(i+" ");
			}
			System.out.println();
		}
	}
}
class patten13
{
	public static void main(String []args)
	{
		int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
		for(int i=n;i>0;i--)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(j+" ");
			}
			System.out.println();
		}
	}
}
class patten5
{
	public static void main(String [] args)
	{
		int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(i==1||i==5||j==1||j==5)
				System.out.print("* ");
			else
				System.out.print("  ");
			}
			System.out.println();
		}
	}
}
class patten6
{
	public static void main(String [] args)
	{
		int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(i==j)
				System.out.print("* ");
			else
				System.out.print("  ");
			}
			System.out.println();
		}
	}
}
class patten7
{
	public static void main(String [] args)
	{
		int n=5;
		for(int i=0;i<n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(j==n-i)
				System.out.print("* ");
			else
				System.out.print("  ");
			}
			System.out.println();
		}
	}
}
class patten8
{
	public static void main(String [] args)
	{
		int n=5;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(i==j)
				System.out.print("* ");
			else
				System.out.print("  ");
			}
			for(int j=1;j<=n;j++)
			{
				if(j==n-i)
				System.out.print("* ");
			else
				System.out.print("  ");
			}
			System.out.println();
			System.out.println();
		}
	}
}
class patten9
{
	public static void main(String [] args)
	{
		int n=5;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(i==5||j==1)
				System.out.print("* ");
			else
				System.out.print("  ");
			}
			System.out.println();
		}
	}
}