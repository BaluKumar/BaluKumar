import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.Scanner;
class s2{
    public static void main(String args[])
    {
    Scanner s=new Scanner(System.in);
    String ch1="abcdefghijklmnopqrstuvwxyz";
   // String ch1=ch.toString();
   // String ch2="a";
    int cnt=0;
    int flag=0;

    for(int i=0;i<ch1.length();i++)
    {
        String ch2=Character.toString(ch1.charAt(i));
        isMatch(ch2,ch1);
    }
}
     public static void isMatch(String ch2,String ch1)
     {
         int flag=0;
         int cnt=0;
     Pattern p=Pattern.compile("ch2[a-z]");
     Matcher m=p.matcher(ch1);
     if(m.find())
     {
        cnt++;
        System.out.print(cnt);
     }
     else
     {
         flag++;
     }

    }
    }
}
