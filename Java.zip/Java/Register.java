public class Register {
    private String name;
    private String password;
    Register(String name,String password){
        this.name=name;
        this.password=password;
    }
    public String getname() {
        return this.name;
    }
    public String getpassword(){
        return this.password;
    }
}

