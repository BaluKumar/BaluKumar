import java.util.Scanner;
class sandeep
{
	public static void main(String args[])
	{
		int a;
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter your age:");
		a=sc.nextInt();
		if(a<=18)
		System.out.println(a+ " "+"Is teen");
		else if(a>18&&a<50)
		System.out.println(a+ " "+"Is adult");
		else
		System.out.println(a+ " "+"Is aged");
	}
}