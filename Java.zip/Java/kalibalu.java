import java.util.*;
class  Kali
{
  public static  void main(String a11[])
  {
     int a1;
    String name="kali";
     Scanner s=new Scanner(System.in);
     a1=s.nextInt();
     //name=s1.nextline();
     if (a1>35)
 {
    System.out.print("The person"+name+"scored:"+a1+"\n is pass");
 }
  else
{
  System.out.print("The person"+name+"scored:"+a1+"\nis fail");
   }
 }
}