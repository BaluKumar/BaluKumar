import java.util.Scanner;
class SampleTest{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        while (true) {
            System.out.println("Register to continue");
            System.out.print("Name:  ");
            String name=s.next();
            System.out.print("\nPassword: ");
            String password=s.next();
            System.out.print("\nRePassword: ");
            String repassword=s.next();
            if(password.equals(repassword)&& name!= null){
                System.out.println("Registerion is sucessfull");
                Register r=new Register(name,password);
                System.out.println("login to continue");
                System.out.print("Name:  ");
                String name1=s.next();
                System.out.print("\nPassword: ");
                String pass=s.next();
                if(name1.equals(r.getname())&& pass.equals(r.getpassword())){
                    System.out.println("Login sucessfull");
                    fibo();
                }else{
                    System.out.println("please enter valid password");
                    System.exit(0);
                }
                break;
            }else{
                System.out.println("please enter valid password");
            }
        }
    }
    public static void fibo() {
        Scanner s=new Scanner(System.in);
        int a,b;
        System.out.println("To print fibonacci series enter two value");
        System.out.print("FirstValue: ");
        a=s.nextInt();
        System.out.print("SecondValue: ");
        b=s.nextInt();
        for (int i = 0; i < 10; i++) {
            System.out.print(a+" ");
            int sum=a+b;
            a=b;
            b=sum;
        }
    }

}