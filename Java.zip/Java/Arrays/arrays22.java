class arrays22
{
    public static void main(String[] args) 
    {
            
    }
}