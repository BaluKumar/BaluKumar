//Design a method to swap two adjacent elements
import java.util.Scanner;
class arrays21
{
    public static void main(String[] args) 
    {
        Scanner sc=new Scanner(System.in);
        //getting input from the user
        System.out.println("Enter the Size:");
        int n=sc.nextInt();
        int []a=new int[n];
        for(int i=0;i<a.length;i++)
        {
            a[i]=sc.nextInt();
        }
        //swap two adjacent elements
        for(int i=0;i<a.length;i+=2)
        {
            if(i+1<a.length)
            System.out.print(a[i+1]+" "+a[i]+" ");
            else
            System.out.println(a[i]+" ");
        }
    }
}