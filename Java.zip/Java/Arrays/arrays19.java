//Design a method to find the first and second smallest elements of the array
import java.util.Scanner;
class arrays19
{
    public static void main(String[]args)
    {
        Scanner sc=new Scanner(System.in);
        int []a=get();
        //getting the which element to be print
        System.out.println("Enter the value :");
        int n=sc.nextInt();
        System.out.println(a[n-1]);
        System.out.println("Enter the value :");
        int b=sc.nextInt();
        System.out.println(a[b-1]);
    }
    public static int[] get()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        return Rearrange(a);
    }
    //Shorting the arrays
    public static int [] Rearrange(int []a)
    {
        for(int i=0;i<a.length-1;i++)
        {
            for(int j=i+1;j<a.length;j++)
            {
                if(a[i]>a[j])
                {
                    a[i]=a[i]+a[j]-(a[j]=a[i]);
                }
            }
        }
        return a;
    }
}