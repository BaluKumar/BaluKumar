//Design a method to calculate the sum and average of the each elements of the arrays
import java.util.Scanner;
class arrays18
{
    public static void main(String[]args)
    {
        int []a=get();
        int sum=0;
        for(int i=0;i<a.length;i++)
        {
            sum+=a[i];
        }
        System.out.println("sum of all elements:"+sum);
        System.out.println("Average of the each elements");
        for(int i=0;i<a.length;i++)
        {
            System.out.println(a[i]/a.length);
        }
    }
    public static int[] get()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        return a;
    }
}