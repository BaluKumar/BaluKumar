//Design a method to return nth smallest elements
import java.util.Scanner;
class arrays14
{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Size :");
        //getting the input from the users
        int n=sc.nextInt();
        System.out.println("Enter n elements ");
        int c=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        //Shorting the arrays
        for(int i=0;i<n-1;i++)
        {
            for(int j=i+1;j<n;j++)
            {
                if(a[i]>a[j])
                {
                    a[i]=a[i]+a[j]-(a[j]=a[i]);
                }
            }
        }
        //printing
        for(int i=0;i<n;i++)
            System.out.print(a[i]+" ");
        System.out.println("\n"+a[c-1]);
    }
}