//Design a method to add unique elements and return from the arrays
import java.util.Scanner;
class arrays13
{
    public static void main(String[]args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter the Size:");
        //geting the value from the user
        int n=sc.nextInt();
        int sum=0;
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        //unique elements
        for(int i=0;i<a.length-1;i++)
        {
            for(int j=i+1;j<a.length;j++)
            {
                if(a[i]==a[j])
                {
                    a[j]=-1;
                }
            }
        }
        //adding the unique elements
        for(int i=0;i<a.length;i++)
        {
            if(a[i]!=-1)
                sum+=a[i];
        }
        System.out.println(sum);
    }
}