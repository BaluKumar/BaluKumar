//Design a method to display number of occurence of each elements in the array
import java.util.Scanner;
class arrays17
{
    public static void main(String []args)
    {
        int []a=get();
        //number of times occured
        int count=1;
        for(int i=0;i<a.length-1;i++)
        {
            for(int j=i+1;j<a.length;j++)
            {
                if(a[i]==a[j])
                {
                    a[j]=-1;
                    count++;
                }
            }
            if(a[i]!=-1)
            System.out.println(a[i]+" is "+count+" times");
    
            count=1;
        }
    }
    //getting the value from the user
    public static int[] get()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        return a;
    }
}