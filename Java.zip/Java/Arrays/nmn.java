import java.util.*;
 
class GFG{
static int sum(int n)
{
    return n * (n - 1) / 2;
}
 

static void BSpattern(int N)
{
    int Val = 0, Pthree = 0,
        cnt = 0, initial = -1;
 
    String s = "**";
    for(int i = 0; i < N; i++)
    {
        cnt = 0;
        if (i > 0)
        {
            System.out.print(s);
            s += "**";
        }
        for(int j = i; j < N; j++)
        {
            if (i > 0)
            {
                cnt++;
            }
            System.out.print(++Val);
            System.out.print("0");
        }
        if (i == 0)
        {
            int Sumbeforelast = sum(Val) * 2;
            Pthree = Val + Sumbeforelast + 1;
            initial = Pthree;
        }
        initial = initial - cnt;
 
        Pthree = initial;
        for(int k = i; k < N; k++)
        {
            System.out.print(Pthree++);
            if (k != N - 1)
            {
                System.out.print("0");
            }
        }
        System.out.println();
    }
}
 

public static void main(String[] args)
{
    Scanner s_name = new Scanner(System. in);
    int N = s_name.nextInt();
    BSpattern(N);
}
}