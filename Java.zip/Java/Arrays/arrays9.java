//Design a method to check how many numbers are divisible by 4,3 and 5 in the arrays.
import java.util.Scanner;
class arrays9
{
    public static void main(String []args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Size :");
        int n=sc.nextInt();
        int a[]=new int[n];
        System.out.println("Enter the value of arrays: ");
        //geting the users from the users
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        //displaing the value which is divisible by 4,3 and 5 
        for(int i=0;i<n;i++)
        {
            if(a[i]%4==0||a[i]%3==0||a[i]%5==0)
            {
                System.out.println(a[i]+" ");
            }
        }
    }
}