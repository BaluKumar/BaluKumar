//Design a method to merge two array elements in zigzag manner
import java.util.Scanner;
class arrays15
{
    public static void main(String []args)
    {
        //getting the value from the user
        int a[]=get();
        int b[]=get();
        int len=a.length+b.length,j=0;
        int c[]=new int[len];
        for(int i=0;i<len;i++)
        {
            if(i%2==0)
            {
                if(i<a.length)
                    c[j++]=a[i];
                if(i<b.length)
                    c[j++]=b[i];
            }else
            {
                if(i<b.length)
                    c[j++]=b[i];
                if(i<a.length)
                    c[j++]=a[i];
            }
        }
        //printting
        System.out.println("values of arrays A");
        for(int i=0;i<a.length;i++)
            System.out.print(a[i]+" ");
        System.out.println("values of arrays B");
        for(int i=0;i<b.length;i++)
            System.out.print(b[i]+" ");
        System.out.println("values of arrays c");
        for(int i=0;i<len;i++)
            System.out.print(c[i]+" ");
    }
    //getting the value from the users
    public static int[] get()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        return a;
    }
}