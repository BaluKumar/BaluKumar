import java.util.Scanner;
class arrays6
{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[n],j=0;
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		a=shortArray(a);//shorting is done in this line
		int arr[]=new int[n];
		//removing duplicate values in array
		for(int k=0;k<n-1;k++)
		{
			if(a[k]!=a[k+1])
			{
				arr[j++]=a[k];
			}
		}
		arr[j++]=a[n-1];
		
		for(int i=0;i<j;i++)
			System.out.print(arr[i]+" ");
	}
	public static int[] shortArray(int []a)
	{
		for(int i=0;i<a.length-1;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]>a[j])
				{
					a[i]=a[i]+a[j]-(a[j]=a[i]);
				}
			}
		}
		return a;
	}
}