//Design a method to return how many perfect numbers are there in the array
import java.util.Scanner;
class arrays11
{
    public static void main(String[]args)
    {
        Scanner sc=new Scanner(System.in);
        int a[]=get();
        int count=0;
        for(int i=0;i<a.length;i++)
        {
            if(checkPerfect(a[i]))
            {
                count++;
            }
        }
        System.out.print("no.of counts: "+count);
    }
    public static int[] get()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        return a;
    }
    public static boolean checkPerfect(int a)
    {
        int sum=0;
            for(int i=1;i<=a/2;i++)
        {
            if(a%i==0)
            {
                sum+=i;
            }
        }
        if(sum==a)
            return true;
        else
            return false;
    }
}