//Design a methood to combine two arrays
import java.util.Scanner;
class arrays12
{
    public static void main(String[]args)
    {
        //geting values from user
        int a[]=get();
        int b[]=get();

        int count=0,n=a.length+b.length;
        int c[]=new int[n];
        //combineing two arrays and stowering into another array
        for(int i=0;i<n;i++)
        {
            if(i<a.length)
                c[count++]=a[i];
            if(i<b.length)
                c[count++]=b[i];
        }
        for(int j=0;j<c.length;j++)
        {
            System.out.print(c[j]+" ");
        }
        System.out.print();
    }
    //geting values from user
    public static int[] get()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        return a;
    }
}