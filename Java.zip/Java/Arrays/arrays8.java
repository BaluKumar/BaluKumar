//Design a method to count how many digits in the arrays(digits not numbers)
import java.util.Scanner;
class arrays8
{
    public static void main(String[]args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Size: ");
        //geting the size of arrays
        int n=sc.nextInt(),count=0;
        int []a=new int[n];
        //geting the value of arrays
        for(int i=0;i<n;i++)
        {
            System.out.println("Enter the "+i+" values ");
            a[i]=sc.nextInt();
        }
        //counting digit of each elements
        for(int i=0;i<n;i++)
        {
            while(a[i]!=0)
            {
                a[i]/=10;
                count++;
            }
        }
        System.out.println(count);
    }
}