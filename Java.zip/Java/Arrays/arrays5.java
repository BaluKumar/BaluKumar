//write a java programe to find number of postive and negative 
import java.util.Scanner;
class arrays5
{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[n],neg=0,pos=0;
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		for(int i=0;i<n;i++)
		{
			if(a[i]>0)
				pos++;
			else if(a[i]<0)
				neg++;
		}
		System.out.println("negative numbers in the array: "+neg);
		System.out.println("Postive numbers in the array: "+pos);
	}
}