//Design a method to merge two sorted array in the sorted form
import java.util.Scanner;
class arrays16
{
    public static void main(String []args)
    {
        int a[]=get(),b[]=get();
        //merging the two sorted arrays
        int len=a.length+b.length,j=0;
        int c[]=new int[len];
        for(int i=0;i<len;i++)
        {
            if(i<a.length)
                c[j++]=a[i];
            if(i<b.length)
                c[j++]=b[i];
        }
        int cr[]=Rearrange(c);
        //printting
        System.out.println("\nvalues of arrays A");
        for(int i=0;i<a.length;i++)
            System.out.print(a[i]+" ");
        System.out.println("\nvalues of arrays B");
        for(int i=0;i<b.length;i++)
            System.out.print(b[i]+" ");
        System.out.println("\nvalues of arrays c");
        for(int i=0;i<len;i++)
            System.out.print(cr[i]+" ");
    }
    //getting the values from the users
    public static int[] get()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the size: ");
        int n=sc.nextInt();
        int a[]=new int[n];
        for(int i=0;i<n;i++)
        {
            a[i]=sc.nextInt();
        }
        return Rearrange(a);
    }
    //Shorting the arrays
    public static int [] Rearrange(int []a)
    {
        for(int i=0;i<a.length-1;i++)
        {
            for(int j=i+1;j<a.length;j++)
            {
                if(a[i]>a[j])
                {
                    a[i]=a[i]+a[j]-(a[j]=a[i]);
                }
            }
        }
        return a;
    }
}