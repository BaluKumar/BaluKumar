//Write a java program to find number of odd number in a array
import java.util.Scanner;
class arrays4
{
	public static void main(String []args)
	{
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int a[]=new int[n],sum=0;
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		for(int i=0;i<n;i++)
		{
			if(a[i]%2==1)
				sum++;
		}
		System.out.println("no.of odd numbers in the array: "+sum);
	}
}