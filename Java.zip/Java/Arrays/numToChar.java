import java.util.Scanner;
import java.util.Scanner;
public class numToChar {
    public static void main(String []args){
        Scanner s=new Scanner(System.in);
        int n[]=new int[4];

        for (int i = 0; i <n.length; i++) {
            n[i]=s.nextInt();
        }
        for (int i = 0; i < n.length; i++) {
            System.out.println(n[i]+"-"+
            /*converts number to char for eg:- 65 = 'A'*/
            (char)n[i]);
        }        
    }
}
