import java.util.Scanner;
public class shorting {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int n=s.nextInt();
        int a[]=new int[n];
        int b[]=new int[n];
        for (int i = 0; i < a.length; i++) {
            a[i]=s.nextInt();
        }
        for (int i = 0; i < b.length; i++) {
            b[i]=s.nextInt();
        }
        //mearing two array
        int c[]=new int[a.length+b.length];
        int j=0;
        for (int i = 0; j< c.length; i++) {
            if (i<a.length) 
                c[j++]=a[i];
            if (i<b.length) 
                c[j++]=b[i];
        }
        //removing dublicate value
        for (int i = 0; i < c.length-1; i++) {
            for (int k = i+1; k < c.length; k++) {
                if (c[i]==c[k]) {
                    c[k]=-1;
                }
            }
        }
        //shortting and printing tha value
        for (int i = 0; i < c.length-1; i++) {
            for (int k = i+1; k < c.length; k++) {
                if (c[i]<c[k]) {
                    c[i]=c[i]+c[k]-(c[k]=c[i]);
                }
            }
            if(c[i]!=-1)
            System.out.print(c[i]+" ");
        }
    }
}
