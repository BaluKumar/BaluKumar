class Banck Driver
{
public static void main(String[]args)
	{
	Banck b=new Banck(1,"Balu",200.0);
	b.display();
	b.deposit(200);
	b.display();
	b.withdraw(600);
	b.display();
}
}