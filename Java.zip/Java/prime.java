//program to print prime numbers
import java.util.Scanner;
class prime
 {
    public static void main(String []args)
     {
       Scanner s=new Scanner(System.in);
       int x=s.nextInt();
       int n=2;
       int c=0,i,flag,cnt=0;
       while(true)
         {
            flag=1;
            for(i=2;i<=x/2;i++)
              {
	if(x%i==0)
	 {
	    flag++;
	    break;
	 }
              }
              if(flag==1)
	c++;
              if(cnt==n)
	break;
              x++;
         }
System.out.println(x+" ");
     }
 }