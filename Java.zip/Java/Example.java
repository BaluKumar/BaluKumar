/*class Animal
{
	Animal()
	{
		System.out.println("Animal");
	}
}
class Wild extends Animal
{
	Wild()
	{
		System.out.println("Wild");
		super();
	}
}
public class Example
{
	public static void main(String [] args)
	{
		Wild wild= new Wild();
	}
}
class test 
{
	int rats =5;
	public static void main(String [] args)
	{
		test t1=new test();
		System.out.println(t1.rats);
		modify(t1.rats);
		System.out.println(t1.rats);
		
	}
	static void modify(int r)
	{
		r=20;
	
	}
}

public class Example
{
	public static void main(String [] args)
	{
		System.out.println("BINGO");
	}
}


class person
{
	public int number;

}

public class Example1
{
	public void dolt(int i,person p)
	{
		i=5;
		p.number=8;
	
	}
	public static void main(String [] args)
	{
		int x=0;
		person p=new person();
		new Example().dolt(x,p);
		System.out.println(x+""+p.number);
		
	}
}*/
import java.lang.*;
import java.util.Scanner;
class Example2
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		String a[]=new String[n];
		int i;String c;
		for(i=0;i<n;i++)
			a[i]=s.nextLine();
		for(i=0;i<n-1;i++)
		{
			c=a[i]+a[i+1];
			System.out.println(Math.pow(c.charAt(i),4));
		}
		
	}
}