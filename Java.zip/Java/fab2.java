//
import java.util.Scanner;
class fab2
 {
   public static void main(String []args)
     {
       Scanner s=new Scanner(System.in);
       int x=s.nextInt();
       int y=s.nextInt();

     }
 }