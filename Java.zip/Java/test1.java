import java.util.Scanner;
public class test1 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        s1=s1.toLowerCase();
        char ch='a';
        int c=0;
        for (int i = 0; i < s1.length(); i++) {
            if (s1.charAt(i)==97) {
                c=0;
                break;
            }else{
                c++;
            }
        }
        if (c==0) {
            System.out.println("The above String is a pangram");
        } else {
            System.out.println("The above String is not pangram");
        }
    }
}
