import java.util.Scanner;
class IterationControl1 
{
	public static void main(String[] args) {
		// Create a Scanner object
		Scanner s = new Scanner(System.in);
		int totalCost = 0;
		char wantToAddFoodItem = 'Y';
		int unitPrice = 10;
		int quantity = 1;
		while (wantToAddFoodItem == 'Y') {
			totalCost = totalCost + (quantity * unitPrice);
			System.out.println("Order placed successfully");
			System.out.println("Total cost: " + totalCost);
			System.out.println("Do you want to add more food items to your order? Y or N");
			String input = s.next(); // Accepting input from the customer
            // Extracting first character from the input string
			wantToAddFoodItem = input.charAt(0); 
		}
	}
}

class IterationControl2
{
	public static void main(String [] args)
	{
		int inputNumber = 7865;
		int sumOfDigits = 0;
		int temp = 0;

		while (inputNumber > 0) {
			temp = inputNumber % 10;
			sumOfDigits += temp;
			inputNumber = inputNumber / 10;
		}
		System.out.println("Sum of digits are : " + sumOfDigits);
	}
}
class IterationControl3
{
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		int totalCost = 0;
		char wantToAddFoodItem = 'Y';
		int unitPrice = 10;
		int quantity = 1;

		while (wantToAddFoodItem == 'Y') {
			totalCost = totalCost + (quantity * unitPrice);
			System.out.println("Order placed successfully");
			System.out.println("Total cost: " + totalCost);
			System.out.println("Do you want to add one more food item to the order?");
			String input = s.next(); 
			wantToAddFoodItem = input.charAt(0);
			
		}
		System.out.println("Thank you for ordering the food! It will reach you shortly...");
	}
}
class IterationControl4 
{
	public static void main(String[] args) 
	{
		int inputNumber = 9654;
		int sumOfDigits = 0;
		int temp = 0;

		do {
			temp = inputNumber % 10;
			sumOfDigits += temp;
			inputNumber = inputNumber / 10;
		} while (inputNumber > 0);

		System.out.println("Sum of digits : " + sumOfDigits);
	}
}
//for loops
class IterationControl5 
{
	public static void main(String[] args) {
		// The below code generates customerId
		int totalNoOfCustomers = 12;
		String customerId = "";
		for (int counter = 1; counter <= totalNoOfCustomers; counter++) {
			if (counter <= 9)
				customerId = "C0" + counter;
			else
				customerId = "C" + counter;
			System.out.println("Customer Id for customer " + counter + " is "
					+ customerId);
		}
	}
}
//Importing the Scanner class
class IterationControl6 
{
	public static void main(String[] args) 
	{
		// Create a Scanner object
		Scanner sc = new Scanner(System.in);
		int totalCost = 0;
		int unitPrice = 10;
		System.out.println("Enter the number of food items to be ordered");
		int noFoodItemsToBeOrdered = sc.nextInt();
		for (int counter = 1; counter <= noFoodItemsToBeOrdered; counter++) {
			System.out.println("Enter the food item");
			String foodItem = sc.next();
			System.out.println("Enter the quantity");
			int quantity = sc.nextInt();
			System.out.println("You have ordered: " + foodItem);
			totalCost += unitPrice * quantity;
			if(totalCost>=300)
			{
				System.out.println("Sorry! totalCost is out of Budget!!!!");
				break;
			}
			System.out.println("Order placed successfully!");
			System.out.println("Total cost of the order: " + totalCost);
		}
	}
}

class IterationControl7
{
	public static void main(String[] args) 
	{
		int rows = 10;
		for (int i = 1; i <= rows; ++i) {
			for (int j = 1; j <= i; ++j) {
                // print displays the text without adding a new line
				System.out.print(j + " "); 
			}
			System.out.println(""); // println displays the text along with a new line
		}
	}
}
class IterationControl8
{
	public static void main(String[] args) 
	{
		for (int row = 1; row <= 4; row++) {
			for (int value = 1; value <= 5; value++) {
				System.out.print(value + " ");
			}
			System.out.println();
		}
	}
}
//Importing the Scanner class
//using break condition
class IterationControl9
{
	public static void main(String[] args) {
		// Create a Scanner object
		Scanner sc = new Scanner(System.in);
		int totalCost = 0;
		int unitPrice = 10;
		System.out.println("Enter the max amount you can pay");
		int maxAmountCustomerCanPay = sc.nextInt();
		System.out.println("Enter the number of food items to be ordered");
		int noFoodItemsToBeOrdered = sc.nextInt();
		for (int counter = 1; counter <= noFoodItemsToBeOrdered; counter++) {
			System.out.println("Enter the food item");
			String foodItem = sc.next();
			System.out.println("Enter the quantity");
			int quantity = sc.nextInt();
			totalCost += unitPrice * quantity;
			if (totalCost > maxAmountCustomerCanPay) {
				System.out.println("Sorry! Total cost is crossing your max amount limit.");
				break;
			}
			System.out.println("You have ordered: " + foodItem);
			System.out.println("Order placed successfully");
			System.out.println("Total cost of the order: " + totalCost);
		}
	}
}
//Importing the Scanner class
//using continue condition
class IterationControl10 
{
	public static void main(String[] args) 
	{
		// Create a Scanner object
		Scanner sc = new Scanner(System.in);
		int totalCost = 0;
		int unitPrice = 10;
		System.out.println("Enter the number of food items to be ordered");
		int noFoodItemsToBeOrdered = sc.nextInt();
		for (int counter = 1; counter <= noFoodItemsToBeOrdered; counter++) {
			if (counter == 3)
				continue;
			System.out.println("Enter the food item");
			String foodItem = sc.next();
			System.out.println("Enter the quantity");
			int quantity = sc.nextInt();
			System.out.println("You have ordered: " + foodItem);
			System.out.println("You have successfully placed the order number: "+ counter);
			totalCost += unitPrice * quantity;
			System.out.println("Total cost of the order: " + totalCost);
		}
	}
}
//<<  Quiz for Control Structures  >>

class IterationControl11 {
	public static void main(String[] args) {
		int i = 1, j = 10;
		do {
			j--;
		} while (++i < 5);
		System.out.println("i = " + i + " and j = " + j);
	}
}
class IterationControl12 {
	public static void main(String[] args) {
		int sum = 0;
		for (int i = 0, j = 0; i < 5 & j < 5; ++i, j = i + 1) {
			sum += i;
		}
		System.out.println(sum);
	}
}
class IterationControl13{
	public static void main(String[] args) {
		for (int i = 0; i < 3; i++) {
			switch (i) {
			case 0:
			case 1:
				System.out.println("One ");
				break;
			case 2:
				System.out.println("Two ");
			}
		}
	}
}
class IterationControl14 {
	public static void main(String[] args) {
		int counter = 1;
		while (counter < 3) {
			counter = counter + 1;
			System.out.println(counter);
		}
	}
}
class IterationControl15{
	public static void main(String[] args) {
		int number = 28;
		for (int num = 25; num < 30; num++) {
			if (number > num) {
				System.out.println(num);
			} else {
				System.out.println(num);
				break;
			}
		}
	}
}
class IterationControl16 {
	public static void main(String[] args) 
	{
		Scanner s=new Scanner(System.in);
		int num1=s.nextInt();
		int num2=s.nextInt();
		while (num1 >= 2) {
			if (num1 > num2) {
				num1 = num1 / 2;
			} else {
				System.out.println(num1);
				break;
			}
		}
	}
}
class IterationControl17 {
	public static void main(String[] args) {
		int counter = 0;
		while (counter <= 7) {
			if (counter % 2 == 0) {
				counter += 1;
				continue;
			} else {
				counter += 1;
			}
			System.out.println(counter);
		}
	}
}
class IterationControl18 {
	public static void main(String[] args) {
		int i = 0;
		for (; i <= 3; i++) {
			if (i++ % 2 == 0) {
				System.out.println("i = " + i);
			}
		}
		System.out.println("i after the loop = " + i);
	}
}
class IterationControl19 {
	public static void main(String[] args) {
		int num1 = 0;
		int num2 = 0;
		for (int i = 0; i < 5; i++) {
			if ((++num1 > 2) && (++num2 > 2)) {
				num1++;
			}
		}
		System.out.println(num1 + " and " + num2);
	}
}
class IterationControl20 {
	public static void main(String[] args) {
		for (int i = 2; i >= i % 2; i--) {
			System.out.println(i);

		}
	}
}
//<<  Exercise1  >>
//Implement a program to calculate the factorial of a given number.
class IterationControl21
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int total=1;
		for(int i=1;i<=n;i++)
		{
			total=total*i;
		}
		System.out.println("Factorial of "+n+" is "+total);
	}
}
//Implement a program to display the geometric sequence as given below for a given value n, where n is the number of elements in the sequence.

//1, 2, 4, 8, 16, 32, 64, ......, 1024
class IterationControl22
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int c=1;
		for(int i=1;i<=n;i++)
		{
			System.out.print(c+" ");
			c=c+c;
		}
	}
}
//Assignment1
class IterationControl23
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int b=s.nextInt();
		int c;
		if(a==b)
		{
			c=a+b;
			System.out.println(c);
		}
		else
		{
			c=a+b;
			System.out.println(c+c);
		}
			
	}
}
class IterationControl24
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();
		int b=s.nextInt();
		int c=s.nextInt();
		int dis=(b*b)-4*a*c;
		float x;
		if(dis==0)
		{
			x=(float)(-b+dis)/2*a;
			System.out.println("The root is"+x);
		}
		else if(dis>0)
		{
			//what are the two real roots
			System.out.println("the roots are unequal real roots"+"\n the values of both the roots are :");
			x=(float)a*(2*2)+b*2+c;
			System.out.print(x+" ");
			x=(float)(-b+dis)/2*a;
			System.out.print(x);
		}
		else if(dis<0)
			System.out.println("The equation has no real root");
	}
}
 