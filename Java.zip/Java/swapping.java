//swap two numbers using three variables
import java.util.Scanner;
class swapping
{
      public static void main(String []ar)
         {
             Scanner s=new Scanner(System.in);
             int a=s.nextInt();
             int b=s.nextInt();
             int c=a;
             a=b;
             b=c;
             System.out.println("-------------------------------------------------");
             System.out.println("Swapping is completed:");
             System.out.print("A:"+a+"\tB:"+b);
         }
}