class Balu
   {
           public static void main(String []args)
	{
	   int a=10, b= 20;
	int c=a+b;
	float x=10;
	char letter= 'a';
	System.out.println("letter");
	System.out.println(x);
}
}
//data type
//number data type
btye
int
long
//letters 
char
//decimal data type
double 
float

bool
String
