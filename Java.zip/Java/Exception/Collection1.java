import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Collection1 
{

    public static void main(String[] args) 
	{
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        String []s1=new String[n];
        for(int i=0;i<n;i++)
        {
            s1[i]=sc.nextLine();
            //sc.nextLine();
        }
        for(int i=0;i<s1.length;i++)
        {
            System.out.println(s1[i]);
        }
    }
}