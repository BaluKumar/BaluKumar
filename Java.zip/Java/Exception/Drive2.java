class Drive2
{
	public static void main(String []args)
	{
		try
		{
			System.out.println(Math.pow(5,0));
			int a,b;
			b=0;
			a=5*b;
			System.out.println(a);
		}catch(ArithmeticException e)
		{
			System.out.println("B");
		}
	}
}