import java.util.Scanner;
class Solution
{
    public static void main(String []argh)
    {
        Scanner sc=new Scanner(System.in);
        int t=sc.nextInt();
        for(int test=0;test<t;test++)
        {
         int a=sc.nextInt();
        int b=sc.nextInt();
        int n=sc.nextInt();
        for(int i=0;i<n;i++)
        {
            int res=a;
            for(int j=0;j<=i;j++)
            {
                res+=powerValue(j,b);
            }
            System.out.print(res+" ");
        }
        System.out.println();   
        }
    }
    public static int powerValue(int pow,int b)
    {
        int k=b*((int)Math.pow(2,pow));
        
     return k;   
    }
}
