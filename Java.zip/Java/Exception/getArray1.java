import java.util.Scanner;
class getArray1
{
	public static int[] getArray(int n)
	{
		Scanner sc=new Scanner(System.in);
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		return a;
	}
}