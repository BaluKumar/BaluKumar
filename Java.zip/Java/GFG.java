class GFG{
static int[] find(int dividend,int divisor,int start,int end)
{
if (start>end)
return new int []{0,dividend};
int mid=start+(end-start)/2;

int n=dividend-divisor*mid;
if(n>divisor)
start=mid+1;

else if(n<0)
end=mid-1;
else{
if(n==divisor){
++mid;
n=0;
}
return new int[]{mid,n};
}
return find(dividend,divisor,start,end);
}
static int[] divide(int dividend,int divisor)
{
return find(dividend,divisor,1,dividend);
}
public static void main(String[]args)
{
int dividend=10,divisor=3;
int []ans=divide(dividend,divisor);

System.out.print(ans[0]+",");
System.out.println(ans[1]+"\n");
}
}