import java.util.Scanner;
/*class nagulan1
{ 
  public static void main(String args[])
  {
	Scanner s=new Scanner(System.in);
	 int i=s.nextInt();//20
   	 if(i>9)
	{
	  System.out.println("more than one digit");
	}
      else if(i<=9)
    {
		if(i>=-9)
      System.out.println("Single digit");
		else
			System.out.println("more than one digit in negtive	");
    }	  
  }
}*/

class nagulan2
{
	public static void main(String [] args)
	{
		Scanner s=new Scanner(System.in);
		int i;
		String c=s.nextLine(),b="";
		for(i=c.length()-1;i>=0;i--)
		{
			b=b+c.charAt(i);
		}
		System.out.println(b);
	}
}