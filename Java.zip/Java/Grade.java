import java.util.*;
 class Thamarai
 {
   public static void main(String[]arg)
   {
     int a1,a2,a3,tot,temp;
     char grade;
     String name;
     Scanner m=new Scanner(System.in);
     int a1=67;
     int a2=44;
     inta3=89;
name=selvam;
tot=a1+a2+a3;
temp=tot/3;
if((temp>=95)&&(temp<=100))
      grade='A';
else if ((temp>=85)&&(temp<=94))
    grade='B';
else if ((temp>=65)&&(temp<=84))
     grade='c';
else if ((temp>0)&&(temp<=64))
     grade='D';
System.out.println("The person"+ name+"grade is"+ grade);
}
}