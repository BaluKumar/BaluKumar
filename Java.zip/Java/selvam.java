import java.util.*;
class  Thamarai 
{
  public static  void main(String arg[])
  {
     int x;
    String name="SELVAM";
     Scanner s=new Scanner(System.in);
     x=s.nextInt();
     //name=s1.nextline();
     if (x>34)
 {
    System.out.print("The person"+name+"scored:"+x+"\n is pass");
 }
  else
{
  System.out.print("The person"+name+"scored:"+x+"\nis fail");
   }
 }
}