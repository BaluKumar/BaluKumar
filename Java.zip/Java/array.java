import java.util.Scanner;
class array1
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int i,j;
		int a[][]=new int[n][n];
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				a[i][j]=s.nextInt();
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				System.out.print(a[i][j]+"  ");
			}
		System.out.println();
		}
	}
}
//write a java program to find the number of element in an array

class array2
{
	public static void main(String []args)
	{
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		int flag=0;
		for(int i=2;i<n/2;i++)
		{
			if(n%i==0)
			flag++;
		}
		   if(flag==0)
			   System.out.println("number is prime");
		   else
			   System.out.println("number is not prime");
			
		
	}
}
