/*write a program to add all postive even numbers when we get 
get negitive odd number the loop should terminated and display 
the add numbers*/ 
import java.util.Scanner;
class negodd
 {
    public static void main(String []args)
       {
        Scanner s=new Scanner(System.in);
        int x,y=0;
        while(true)
            {
               x=s.nextInt();
               if(x%2!=-1)
	{
	  if(x>0&&x%2==0)
	         y=y+x;
	}
	else
	    break;
            }		
              System.out.println(y);
       }
}

