import java.util.Scanner;
class math{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int a=s.nextInt();
        char ch=s.next().charAt(0);
        int  b=s.nextInt();
        switch (ch) {
            case '+':
                System.out.println(a+b);
                break;
            case '-':
                System.out.println(a-b);
                break;
            case '*':
                System.out.println(a*b);    
                break;
            case '/':
                System.out.println(a/b);    
                break;
        }
    }
}