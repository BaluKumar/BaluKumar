import java.util.Scanner;

public class two {
    public static String twonum(int n){
        String value="";
        String []fname={"twenty","thirty","forty","fifty","Sixty","seventy","eighty","ninety"};
            String [] name ={"One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
            
            int lnum=n%10;
            switch(n/10){
            case 2:value=fname[0];
            break;
            case 3:value=fname[1];
            break;
            case 4:value=fname[2];
            break;
            case 5:value=fname[3];
            break;
            case 6:value=fname[4];
            break;
            case 7:value=fname[5];
            break;
            case 8:value=fname[6];
            break;
            case 9:value=fname[7];
        }
        switch(lnum){
            case 1:value=value+name[0];
            break;
            case 2:value=value+name[1];
            break;
            case 3:value=value+name[2];
            break;
            case 4:value=value+name[3];
            break;
            case 5:value=value+name[4];
            break;
            case 6:value=value+name[5];
            break;
            case 7:value=value+name[6];
            break;
            case 8:value=value+name[7];
            break;
            case 9:value=value+name[8];
        
        }
        return value;
    }
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        int a=s.nextInt();
        s.close();
        System.out.print(twonum(a));
    }
}
