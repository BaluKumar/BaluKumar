class swamp3no
 {
   public static void main(String []x)
	{
	 int x1=Integer.praseInt(x[0]);
	 int x2=Integer.praseInt(x[1]);
	 int x3=Integer.praseInt(x[2]);
	 x1=x1+x2+x3;
	 x2=x1-(x2+x3);
	 x3=x1-(x2+x3);
	 x1=x1-(x2+x3);

	}
 }