class Buffer
 {  
  public static void main(String args[])
   {  
    StringBuffer s1=new StringBuffer("Vasavi");
    StringBuffer s2=new StringBuffer("Engineering");
    StringBuffer s3=new StringBuffer();
    StringBuffer s4=new StringBuffer(10);  
    System.out.println(s1.capacity());
    System.out.println(s3.capacity());
    System.out.println(s4.capacity());
    System.out.println(s1.length()+"   "+s4.length());
  //  System.out.println(s2.charAt(4)+"   "+s3.charAt(6));
    s1.append(s2);  
    System.out.println(s1+"   "+s2);  
    s2.insert(2,"Vasavi"); 
    System.out.println(s2);  
    s1.reverse();  
    System.out.println(s1); 
    s2.delete(5,8);  
    System.out.println(s2);  
    s2.replace(2,5,"College");  
    System.out.println(s2);
  }  
} 
