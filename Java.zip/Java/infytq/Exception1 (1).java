class Exception1
  {
   public static void main(String[] args)
    {
       int c=0;
       int a=Integer.parseInt(args[0]);
       int b=Integer.parseInt(args[1]);
    try 
      {
       c=a/b;
       System.out.println(c);
     }

    catch (ArithmeticException e)
      {
      System.out.println("ArithmeticException => " + e.getMessage());
     }
  }
}