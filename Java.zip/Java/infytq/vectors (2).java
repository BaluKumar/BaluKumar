import java.util.Vector;
class vectors1
  {  
    public static void main(String args[]) {  
    Vector<Integer> vec=new Vector<Integer>(5,5);  
    System.out.println("Size"+vec.size());  
    System.out.println("Size"+vec.capacity());  

    vec.add(10);  
    vec.add(20);  
    vec.add(30);  
    System.out.println("Elements are: "+vec);  
    System.out.println("Size"+vec.size());  
    System.out.println("Size"+vec.capacity());  
    vec.addElement(5);  
    vec.addElement(10);  
    System.out.println("Elements are: "+vec);  
    System.out.println("Size"+vec.size());  
    System.out.println("Size"+vec.capacity());  
    vec.addElement(15);
    vec.addElement(20);
    vec.addElement(25);  
    System.out.println("Elements are: "+vec);  
    System.out.println("Size"+vec.size());  
    System.out.println("Size"+vec.capacity());  
   vec.remove(0);         
    System.out.println("Size"+vec.size());  
    System.out.println("Size"+vec.capacity());  
          System.out.println("Elements are: "+vec);  
   vec.remove((Integer)25);         
    System.out.println("Size"+vec.size());  
    System.out.println("Size"+vec.capacity());  
          System.out.println("Elements are: "+vec);  

       }  
}  