import java.util.LinkedList;  
import java.util.Iterator;
class LinkedList1
 {  
 public static void main(String args[]){  
  LinkedList<Integer> marks=new LinkedList<Integer>();  
   marks.add(78);
   marks.add(25);
   marks.add(39);
   marks.add(90);
   marks.add(20);
   System.out.println(marks);
   marks.add(2,100);
   System.out.println(marks);
   marks.addFirst(50);
   marks.addLast(50);
   System.out.println(marks);
   System.out.println(marks.indexOf(50));
   System.out.println(marks.lastIndexOf(50));
   for(int i=0;i<marks.size();i++)
       System.out.print(marks.get(i)+"  ");
   System.out.println("\n");
     marks.set(7,75);

  Iterator<Integer> i=marks.iterator();  
   while(i.hasNext())
     {  
       System.out.println(i.next());  
     }  
  }  
}  