public class person
{
   public void talk()
        {
           System.out.print("I am a Person");
        }
}
public class Student extends person
{
  public void talk()
       {
           System.out.print("I am a Student");
       }
}
public class Test
{
public static void main(String args[])
     {
        person p=new Student();
        p.talk();
     }
}