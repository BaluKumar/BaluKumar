import java.util.ArrayList;
class arrlist2
{
  public static void main(String[] args)
      {
         int a[]=new int[10];
         ArrayList<Integer>arrList2=new ArrayList<Integer>();
         arrlist2.add(12);
         arrlist2.add(20);
         arrlist2.add(23);
         arrlist2.add(-10);
         arrlist2.add(29);
        for(int=0;i<arrlist2.size();i++)
              {
                   Integer n=Integer.valueOf(arrlist2.get(i));
                   a[i]=n.int value()
              }
      }
}