import java.util.Scanner;
public class swap {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String s1=s.nextLine();
        s.close();
        String str[]=s1.split(" ");
        String res="";
        for (int i = 0; i < str.length; i++) {
            for (int j =1 ; j < str[i].length(); j++) {
                res+=str[i].charAt(j);
            }
            res+=str[i].charAt(0);
            res+="Centizen ";
        }
        System.out.println(res);
    }
}
class test{
    p
}