import java .util.Scanner;
class Test
{public static void main(String[]args)
{
Scanner sc=new Scanner(System.in);
System.out.println("enter a nuber 1:");
int num1=sc.nextInt();
System.out.println("enter a number 2:");
int num2=sc.nextInt();
System.out.println("enter a number 3:");
int num3=sc.nextInt();
int res=num1+num2+num3;
System.out.println("the sum of three number s is:"+res);
}
}	