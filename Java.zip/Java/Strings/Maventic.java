//BaNana--->BaaaNNaaannaaa
import java.util.Scanner;
class Maventic
{
    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        String s=sc.next();
        sc.close();
        String s1="";
        int count=0;
        char []ch=s.toCharArray();
        String s2=s.toLowerCase();
        for (int i = 0; i < ch.length; i++) {
            for (int j = 0; j < ch.length; j++) {
                if (s2.charAt(i)==s2.charAt(j)) {
                    count++;
                }
            }
            for (int j = 0; j < count; j++) {
                s1=s1+ch[i];
            }count=0;
        }
        System.out.println(s1);
    }
}