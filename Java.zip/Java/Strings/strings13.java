/**Design a method to find all the words less than 3 characters.
 * strings13
 */
public class strings13 {

    public static void main(String[] args) {
        
    }
}