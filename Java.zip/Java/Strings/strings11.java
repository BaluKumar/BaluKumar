/**Design a method to enter a string then convert it into upper case
 * strings11
 */
public class strings11 {

    public static void main(String[] args) {
        
    }
}