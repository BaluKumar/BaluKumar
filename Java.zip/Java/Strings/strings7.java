//Design a method to reverse the string ,words in a given sentence
import java.util.Scanner;
public class strings7 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the values");
        String s=sc.nextLine();
        String []str=s.split(" ");
        for (int i = 0; i < str.length; i++) {
            String s1=str[i];
            for (int j = s1.length()-1;j>=0 ; j--) {
                System.out.print(s1.charAt(j));
            }
            System.out.print(" ");
        }
    }
}
