import java.util.Scanner;
class HackerRanck_Test1{
    public static void main(String []args) {
        String []s1={"50" ,"20" ,"30 ","46" ,"98"};
        String s2="hi";        
        for (int i = 0; i < s1.length; i++) {
            char []ch=s1[i].toCharArray();
            for (int j = 0; j < ch.length; j++) {
                if(ch[j]>='0'&& ch[j]<='9'){
                    s2=sum(s2, ch[j]);
                }else{
                    s2=s2+ch[j];
                }
            }
        }
        System.out.println(s2);
    }
    public static String sum(String s,char c) {
        // Enter your code here for adding string value and char value
        
        return " ";
    }
}