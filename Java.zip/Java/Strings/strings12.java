/**Design a method to check & count the occurrence of character in the given string
 * strings12
 */
public class strings12 {

    public static void main(String[] args) {
        
    }
}