public class simpleGame {
    public static void main(String[] args) {
        
    }
}
