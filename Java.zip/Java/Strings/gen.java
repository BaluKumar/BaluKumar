public class gen {
    public static void main(String[] args) {
       gen d=new gen();
       d.name("data");
       int a=12;
       d.name(a);
       /*Scanner s=new Scanner(System.in);
       while (true) {
        String st=s.nextLine();
        d.name("your enterd data "+st);
        if(st.equals("b"))
        break;
        s.close();
       }*/
       d.name(10);
       d.name(10.2);
       d.name("balu");
       d.name('b');
       
    }
    //generic method
    public <T> void name(T data) {
        System.out.println(data.va);
        
    }
}