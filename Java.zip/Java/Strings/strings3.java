import java.util.Scanner;
class strings3 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value");
        String str=sc.nextLine();
        String []s1=str.split(" ");
        System.out.println(s1.length);
    }
}
