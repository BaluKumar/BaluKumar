//Design a method to enter a string then delete the vowels from string 
/**
 * strings10
 */
public class strings10 {
    public static void main(String[] args) {
        
    }
}