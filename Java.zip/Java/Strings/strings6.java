/*
pangram is nothing about checking all the letters present or not
if it's  prsent it's pangram
else 
not a pangram
case 1:
input: The quick brown fox jumps over the lazy dog
output: The above String is a pangram
case 2:
input:  balu
output:  The above string is not a pangram
*/
import java.util.*;;
class string6 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        System.out.println("Input :"+s1);
        int count=0;
        char []ch={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
        
        for (int i = 0; i < ch.length; i++) {
            if(!(check(ch[i],s1)))
            {
                count++;
                break;
            }
        }
        if (count==0) {
            System.out.println("The above String is a pangram");
        } else {
            System.out.println("The above String is not pangram");
        }
    }
    public static boolean check(char ch,String s1) {
        int c=0;
        for (int i = 0; i < s1.length(); i++) {
            if (s1.charAt(i)==ch) {
                c=0;
                break;
            }else{
                c++;
            }
        }
        if (c==0) {
            return true;
        } else {
            return false;
        }
    }
}
