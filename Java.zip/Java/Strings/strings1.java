/*Design a method to count number of vowels, consonants,digits,
special characters, capital letter small letter in the given string*/
/**
 * strings1
 */
import java.util.Scanner;
public class strings1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a string value");
        String s1=sc.nextLine();
        char[]ch=s1.toCharArray();
        int v=0,c=0,d=0,sp=0,cl=0,sl=0;
        for (int i = 0; i < ch.length; i++) {
            if (ch[i]=='a'||ch[i]=='e'||ch[i]=='i'||ch[i]=='o'||ch[i]=='u'||
            ch[i]=='A'||ch[i]=='E'||ch[i]=='I'||ch[i]=='O'||ch[i]=='U') {
                v++;
            }else if(ch[i]>='a'&&ch[i]<='z'||ch[i]>='A'&&ch[i]<='Z'){
                c++;
            }
            if (ch[i]>='a'&&ch[i]<='z') {
                sl++;
            }else if (ch[i]>='A'&&ch[i]<='Z') {
                cl++;
            } else if (ch[i]>='0'&&ch[i]<='9') {
                d++;
            } else {
                sp++;
            }
        }
        System.out.println("vowels"+v+" consonants"+c+"digits"+d+
        "special characters"+sp+" capital letter"+cl+" small letter"+sl);
    }
}