import java.util.Scanner;
class strings2 {

    public static void main(String []args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value");
        String s=sc.nextLine();
        String []s1=s.split(" ");
        for (int i = 0; i < s1.length; i++) {
            System.out.println(s1[i]+" "+checklength(s1[i]));
        }
    }
    public static int checklength(String s) {
        return s.length();
    }
}
