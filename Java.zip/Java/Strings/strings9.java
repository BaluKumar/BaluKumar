//Design a method to remove the blank spaces from the string
import java.util.Scanner;
public class strings9 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the value ");
        String s=sc.nextLine();
        System.out.println(s.trim());
    }
}