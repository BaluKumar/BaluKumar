class StringBufferExample
{
   public static void main(String args[])
    {
       StringBuffer sb=new StringBuffer("Hello");
       sb.append("Java");
       System.out.println(sb);
    }
}

